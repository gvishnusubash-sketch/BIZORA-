import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { BusinessDataProvider } from './contexts/BusinessDataContext';
import { SignInScreen } from './components/auth/SignInScreen';
import { OnboardingScreen } from './components/auth/OnboardingScreen';
import { AppShell, type NavTab } from './components/layout/AppShell';
import { DashboardModule } from './components/modules/DashboardModule';
import { InventoryModule } from './components/modules/InventoryModule';
import { SalesBillingModule } from './components/modules/SalesBillingModule';
import { PeopleModule } from './components/modules/PeopleModule';
import { ReportsModule } from './components/modules/ReportsModule';
import { SettingsModule } from './components/modules/SettingsModule';
import { ErrorBoundary } from './components/ui/ErrorBoundary';
import { Modal } from './components/ui/Modal';
import { FormErrorBanner } from './components/ui/DataPrimitives';
import { FIELD_LIMITS, isValidGstin } from './lib/validation';

function CreateWorkspaceModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { createBusiness, launchDemoStore } = useAuth();
  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [invoicePrefix, setInvoicePrefix] = useState('INV');
  const [gstin, setGstin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (name.trim().length < 2) return setError('Business name must be at least 2 characters.');
    if (gstin.trim() && !isValidGstin(gstin)) return setError('Invalid 15-character GSTIN format.');

    setSaving(true);
    try {
      await createBusiness({
        name: name.trim(),
        city: city.trim(),
        invoicePrefix: invoicePrefix.trim().toUpperCase() || 'INV',
        gstEnabled: true,
        gstin: gstin.trim().toUpperCase(),
        isDemo: false,
      });
      setName('');
      setCity('');
      setGstin('');
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create workspace.');
    } finally {
      setSaving(false);
    }
  };

  const handleDemo = async () => {
    setError(null);
    setSaving(true);
    try {
      await launchDemoStore();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create demo workspace.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Add Business Workspace"
      subtitle="Create a separate store ledger or launch a sample demo store"
    >
      <div className="space-y-4">
        <FormErrorBanner message={error} />
        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Business Name *</label>
            <input
              type="text"
              required
              maxLength={FIELD_LIMITS.businessName.max}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Anand Electronics Hub"
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">City</label>
              <input
                type="text"
                maxLength={FIELD_LIMITS.city.max}
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Invoice Prefix</label>
              <input
                type="text"
                maxLength={FIELD_LIMITS.invoicePrefix.max}
                value={invoicePrefix}
                onChange={(e) => setInvoicePrefix(e.target.value.toUpperCase())}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono uppercase"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">GSTIN (Optional)</label>
            <input
              type="text"
              maxLength={15}
              value={gstin}
              onChange={(e) => setGstin(e.target.value.toUpperCase())}
              placeholder="29AABCU9603R1ZM"
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono uppercase"
            />
          </div>
          <button
            type="submit"
            disabled={saving}
            className="w-full min-h-[42px] rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
          >
            {saving ? 'Creating...' : 'Create Real Business'}
          </button>
        </form>

        <div className="pt-3 border-t border-slate-100 text-center">
          <button
            type="button"
            disabled={saving}
            onClick={handleDemo}
            className="text-xs font-semibold text-slate-600 hover:text-slate-900 underline cursor-pointer"
          >
            Or launch a fresh Sample Demo Store
          </button>
        </div>
      </div>
    </Modal>
  );
}

function BizoraWorkspace() {
  const { user, activeBusiness, role, authLoading, workspaceLoading, permissions } = useAuth();
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [newBillSignal, setNewBillSignal] = useState(0);
  const [workspaceModalOpen, setWorkspaceModalOpen] = useState(false);

  if (authLoading || workspaceLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 gap-3">
        <div className="w-10 h-10 rounded-xl bg-[#0B1528] text-white font-display font-bold flex items-center justify-center animate-pulse">
          B
        </div>
        <p className="text-xs font-medium text-slate-500">Loading BIZORA workspace...</p>
      </div>
    );
  }

  if (!user) {
    return <SignInScreen />;
  }

  if (!activeBusiness || !role) {
    return <OnboardingScreen />;
  }

  const handleSelectTab = (tab: NavTab) => {
    if (tab === 'sales' && !permissions.canBill) return;
    if (tab === 'people' && !permissions.canViewCustomers && !permissions.canManageStaff) return;
    if (tab === 'reports' && !permissions.canViewFinance && !permissions.canManageInventory) return;
    if (tab === 'settings' && !permissions.canManageSettings) return;
    setActiveTab(tab);
  };

  const handleNewBillShortcut = () => {
    setActiveTab('sales');
    setNewBillSignal((n) => n + 1);
  };

  return (
    <BusinessDataProvider>
      <AppShell
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        onNewSaleShortcut={handleNewBillShortcut}
        onNewBusinessModal={() => setWorkspaceModalOpen(true)}
      >
        {activeTab === 'dashboard' && <DashboardModule onNavigate={handleSelectTab} />}
        {activeTab === 'inventory' && <InventoryModule />}
        {activeTab === 'sales' && permissions.canBill && (
          <SalesBillingModule openNewBillSignal={newBillSignal} />
        )}
        {activeTab === 'people' && (permissions.canViewCustomers || permissions.canManageStaff) && (
          <PeopleModule />
        )}
        {activeTab === 'reports' && (permissions.canViewFinance || permissions.canManageInventory) && (
          <ReportsModule />
        )}
        {activeTab === 'settings' && permissions.canManageSettings && <SettingsModule />}
      </AppShell>

      <CreateWorkspaceModal
        open={workspaceModalOpen}
        onClose={() => setWorkspaceModalOpen(false)}
      />
    </BusinessDataProvider>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <BizoraWorkspace />
      </AuthProvider>
    </ErrorBoundary>
  );
}
