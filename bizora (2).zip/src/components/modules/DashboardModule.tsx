import { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowUpRight,
  Package,
  ReceiptIndianRupee,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useBusinessData } from '../../contexts/BusinessDataContext';
import {
  formatCount,
  formatDateIN,
  formatINR,
  formatShortDay,
  toDateObj,
  toInputDateString,
} from '../../lib/formatters';
import type { DateRangePreset } from '../../types/bizora';
import { HorizontalBarBreakdown, RevenueTrendChart, type TrendPoint } from '../ui/Charts';
import { EmptyState, StatCard, TableSkeleton } from '../ui/DataPrimitives';
import type { NavTab } from '../layout/AppShell';

interface DashboardModuleProps {
  onNavigate: (tab: NavTab) => void;
}

export function DashboardModule({ onNavigate }: DashboardModuleProps) {
  const { permissions, activeBusiness } = useAuth();
  const { products, sales, expenses, customers, payments, loading } = useBusinessData();

  const [preset, setPreset] = useState<DateRangePreset>('month');
  const [customStart, setCustomStart] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 14);
    return toInputDateString(d);
  });
  const [customEnd, setCustomEnd] = useState(() => toInputDateString(new Date()));

  const { startDate, endDate, rangeLabel } = useMemo(() => {
    const now = new Date();
    const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
    const start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);

    if (preset === 'today') {
      return { startDate: start, endDate: end, rangeLabel: 'Today' };
    }
    if (preset === 'week') {
      start.setDate(start.getDate() - 6);
      return { startDate: start, endDate: end, rangeLabel: 'Last 7 days' };
    }
    if (preset === 'month') {
      start.setDate(1);
      return { startDate: start, endDate: end, rangeLabel: 'This month' };
    }
    const cs = new Date(`${customStart}T00:00:00`);
    const ce = new Date(`${customEnd}T23:59:59.999`);
    return {
      startDate: Number.isNaN(cs.getTime()) ? start : cs,
      endDate: Number.isNaN(ce.getTime()) ? end : ce,
      rangeLabel: `${customStart} to ${customEnd}`,
    };
  }, [preset, customStart, customEnd]);

  const filteredSales = useMemo(() => {
    return sales.filter((s) => {
      const dt = toDateObj(s.saleDate);
      return dt >= startDate && dt <= endDate;
    });
  }, [sales, startDate, endDate]);

  const completedSales = useMemo(
    () => filteredSales.filter((s) => s.status === 'completed'),
    [filteredSales]
  );

  const filteredExpenses = useMemo(() => {
    return expenses.filter((e) => {
      const dt = toDateObj(e.expenseDate);
      return dt >= startDate && dt <= endDate;
    });
  }, [expenses, startDate, endDate]);

  const metrics = useMemo(() => {
    const totalSales = completedSales.reduce((sum, s) => sum + s.grandTotal, 0);
    const totalTax = completedSales.reduce((sum, s) => sum + s.taxTotal, 0);
    const totalCogs = completedSales.reduce((sum, s) => sum + s.cogsTotal, 0);
    const operatingExpenses = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
    const netRevenueExclTax = totalSales - totalTax;
    const grossProfit = netRevenueExclTax - totalCogs;
    const netProfit = grossProfit - operatingExpenses;
    const outstandingPayments = customers.reduce((sum, c) => sum + c.outstandingBalance, 0);
    const orderCount = completedSales.length;
    const avgOrderValue = orderCount > 0 ? totalSales / orderCount : 0;

    return {
      totalSales,
      totalCogs,
      operatingExpenses,
      totalExpensesWithCogs: operatingExpenses + totalCogs,
      grossProfit,
      netProfit,
      outstandingPayments,
      orderCount,
      avgOrderValue,
      returnedCount: filteredSales.filter((s) => s.status !== 'completed').length,
    };
  }, [completedSales, filteredExpenses, customers, filteredSales]);

  const lowStockProducts = useMemo(
    () =>
      products
        .filter((p) => p.currentStock <= p.lowStockThreshold)
        .sort((a, b) => a.currentStock - b.currentStock),
    [products]
  );

  const trendData: TrendPoint[] = useMemo(() => {
    const buckets = new Map<string, { label: string; sales: number; expenses: number; sortKey: number }>();

    // Generate continuous day buckets if range <= 35 days
    const diffDays = Math.max(1, Math.ceil((endDate.getTime() - startDate.getTime()) / 86400000));
    if (diffDays <= 35) {
      for (let i = 0; i < diffDays; i++) {
        const d = new Date(startDate.getTime() + i * 86400000);
        const key = toInputDateString(d);
        buckets.set(key, {
          label: formatShortDay(d),
          sales: 0,
          expenses: 0,
          sortKey: d.getTime(),
        });
      }
    }

    for (const s of completedSales) {
      const d = toDateObj(s.saleDate);
      const key = toInputDateString(d);
      const existing = buckets.get(key) || {
        label: formatShortDay(d),
        sales: 0,
        expenses: 0,
        sortKey: new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(),
      };
      existing.sales += s.grandTotal;
      buckets.set(key, existing);
    }

    for (const e of filteredExpenses) {
      const d = toDateObj(e.expenseDate);
      const key = toInputDateString(d);
      const existing = buckets.get(key) || {
        label: formatShortDay(d),
        sales: 0,
        expenses: 0,
        sortKey: new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(),
      };
      existing.expenses += e.amount;
      buckets.set(key, existing);
    }

    return Array.from(buckets.values())
      .sort((a, b) => a.sortKey - b.sortKey)
      .map(({ label, sales: s, expenses: ex }) => ({ label, sales: s, expenses: ex }));
  }, [completedSales, filteredExpenses, startDate, endDate]);

  const paymentBreakdown = useMemo(() => {
    const map = new Map<string, number>();
    for (const s of completedSales) {
      const label =
        s.paymentMethod === 'upi'
          ? 'UPI'
          : s.paymentMethod === 'cash'
            ? 'Cash'
            : s.paymentMethod === 'card'
              ? 'Card'
              : s.paymentMethod === 'bank_transfer'
                ? 'Bank Transfer'
                : 'Credit / Khata';
      map.set(label, (map.get(label) || 0) + s.grandTotal);
    }
    return Array.from(map.entries())
      .map(([label, value]) => ({ label, value }))
      .sort((a, b) => b.value - a.value);
  }, [completedSales]);

  const recentTransactions = useMemo(() => {
    type TxRow = {
      id: string;
      type: 'Sale' | 'Payment' | 'Expense';
      title: string;
      subtitle: string;
      amount: number;
      isCredit: boolean;
      date: Date;
    };
    const rows: TxRow[] = [];

    for (const s of sales.slice(0, 10)) {
      rows.push({
        id: `s_${s.id}`,
        type: 'Sale',
        title: `${s.invoiceNumber} · ${s.customerName}`,
        subtitle: `${s.status === 'completed' ? s.paymentMethod.toUpperCase() : s.status.toUpperCase()}`,
        amount: s.grandTotal,
        isCredit: s.status === 'completed',
        date: toDateObj(s.saleDate),
      });
    }
    for (const p of payments.slice(0, 6)) {
      rows.push({
        id: `p_${p.id}`,
        type: 'Payment',
        title: `Collection · ${p.customerName}`,
        subtitle: `${p.method.toUpperCase()}${p.invoiceNumber ? ` · ${p.invoiceNumber}` : ''}`,
        amount: p.amount,
        isCredit: true,
        date: toDateObj(p.paymentDate),
      });
    }
    for (const e of expenses.slice(0, 6)) {
      rows.push({
        id: `e_${e.id}`,
        type: 'Expense',
        title: e.title,
        subtitle: e.category.replace('_', ' '),
        amount: e.amount,
        isCredit: false,
        date: toDateObj(e.expenseDate),
      });
    }

    return rows.sort((a, b) => b.date.getTime() - a.date.getTime()).slice(0, 8);
  }, [sales, payments, expenses]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-24 bg-white border border-slate-200 rounded-xl animate-pulse" />
          ))}
        </div>
        <TableSkeleton rows={5} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header & Date Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900">
            {activeBusiness?.name || 'Business Overview'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Live metrics calculated from stored records · {rangeLabel}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex items-center p-1 bg-slate-200/70 rounded-lg">
            {(
              [
                { id: 'today', label: 'Today' },
                { id: 'week', label: 'This Week' },
                { id: 'month', label: 'This Month' },
                { id: 'custom', label: 'Custom' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setPreset(opt.id)}
                className={`min-h-[34px] px-3 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  preset === opt.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {preset === 'custom' && (
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={customStart}
                onChange={(e) => setCustomStart(e.target.value)}
                aria-label="Start date"
                className="min-h-[38px] px-2.5 py-1 rounded-lg border border-slate-200 bg-white text-xs font-mono"
              />
              <span className="text-xs text-slate-400">to</span>
              <input
                type="date"
                value={customEnd}
                onChange={(e) => setCustomEnd(e.target.value)}
                aria-label="End date"
                className="min-h-[38px] px-2.5 py-1 rounded-lg border border-slate-200 bg-white text-xs font-mono"
              />
            </div>
          )}
        </div>
      </div>

      {/* Role-aware KPI Grid */}
      {permissions.canBill ? (
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
          <StatCard
            label="Total Sales"
            value={formatINR(metrics.totalSales)}
            subtext={`${formatCount(metrics.orderCount)} completed bills`}
            tone="emerald"
          />
          {permissions.canViewFinance ? (
            <>
              <StatCard
                label="Operating Expenses"
                value={formatINR(metrics.operatingExpenses)}
                subtext={`COGS: ${formatINR(metrics.totalCogs)}`}
              />
              <StatCard
                label="Net Profit"
                value={formatINR(metrics.netProfit)}
                subtext={`Gross margin: ${formatINR(metrics.grossProfit)}`}
                tone={metrics.netProfit >= 0 ? 'emerald' : 'rose'}
              />
            </>
          ) : (
            <StatCard
              label="Avg. Bill Value"
              value={formatINR(metrics.avgOrderValue)}
              subtext={`${metrics.returnedCount} returns/cancels`}
            />
          )}
          <StatCard
            label="Outstanding Receivables"
            value={formatINR(metrics.outstandingPayments)}
            subtext="Pending customer dues"
            tone={metrics.outstandingPayments > 0 ? 'amber' : 'default'}
          />
          <StatCard
            label="Low-Stock Alerts"
            value={formatCount(lowStockProducts.length)}
            subtext={`Out of ${formatCount(products.length)} SKUs`}
            tone={lowStockProducts.length > 0 ? 'rose' : 'emerald'}
          />
        </div>
      ) : (
        /* Inventory-only role KPIs (strictly hides financial/customer totals) */
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          <StatCard
            label="Total Active SKUs"
            value={formatCount(products.length)}
            subtext="Tracked inventory items"
          />
          <StatCard
            label="Total Units in Stock"
            value={formatCount(products.reduce((s, p) => s + p.currentStock, 0))}
            subtext="Across all categories"
            tone="emerald"
          />
          <StatCard
            label="Low-Stock Alerts"
            value={formatCount(lowStockProducts.length)}
            subtext="At or below threshold"
            tone={lowStockProducts.length > 0 ? 'rose' : 'emerald'}
          />
          <StatCard
            label="Out of Stock"
            value={formatCount(products.filter((p) => p.currentStock === 0).length)}
            subtext="Requires urgent restock"
            tone={products.some((p) => p.currentStock === 0) ? 'rose' : 'default'}
          />
        </div>
      )}

      {/* Charts + Performance Summary */}
      {permissions.canBill && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">Sales & Expense Trend</h3>
                <p className="text-xs text-slate-500">Daily revenue vs recorded operating expenses</p>
              </div>
              {permissions.canViewFinance && (
                <button
                  type="button"
                  onClick={() => onNavigate('reports')}
                  className="text-xs font-medium text-emerald-700 hover:text-emerald-800 inline-flex items-center gap-1 cursor-pointer"
                >
                  <span>Full Reports</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <RevenueTrendChart data={trendData} />
          </div>

          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Payment Method Mix</h3>
              <p className="text-xs text-slate-500">Share of completed sales in {rangeLabel.toLowerCase()}</p>
            </div>
            <HorizontalBarBreakdown
              items={paymentBreakdown}
              emptyText="No completed sales in this date range."
            />

            {permissions.canViewFinance && (
              <div className="pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                <div className="font-semibold text-slate-900">Performance Summary</div>
                <div className="flex justify-between">
                  <span>Average Order Value</span>
                  <span className="font-mono tabular-nums font-medium text-slate-900">
                    {formatINR(metrics.avgOrderValue)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Returns / Cancelled</span>
                  <span className="font-mono tabular-nums font-medium text-slate-900">
                    {formatCount(metrics.returnedCount)}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Alerts & Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Inventory Alerts */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <h3 className="text-sm font-semibold text-slate-900">Inventory Alerts</h3>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('inventory')}
              className="text-xs font-medium text-emerald-700 hover:text-emerald-800 cursor-pointer"
            >
              Manage Stock
            </button>
          </div>

          {lowStockProducts.length === 0 ? (
            <div className="py-6 text-center text-xs text-slate-500">
              All products are above their low-stock alert thresholds.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {lowStockProducts.slice(0, 6).map((p) => (
                <div key={p.id} className="py-2.5 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-slate-900 truncate">{p.name}</div>
                    <div className="text-xs text-slate-500 truncate">
                      {p.sku} · Alert at ≤ {p.lowStockThreshold} {p.unit}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div
                      className={`text-sm font-mono font-semibold tabular-nums ${
                        p.currentStock === 0 ? 'text-rose-600' : 'text-amber-700'
                      }`}
                    >
                      {p.currentStock} {p.unit}
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {p.currentStock === 0 ? 'Out of stock' : 'Low stock'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Transactions */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <ReceiptIndianRupee className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-semibold text-slate-900">Recent Transactions</h3>
            </div>
            {permissions.canBill && (
              <button
                type="button"
                onClick={() => onNavigate('sales')}
                className="text-xs font-medium text-emerald-700 hover:text-emerald-800 cursor-pointer"
              >
                All Invoices
              </button>
            )}
          </div>

          {!permissions.canBill ? (
            <EmptyState
              icon={Package}
              title="Inventory Role Active"
              description="Financial transactions are hidden for Inventory Clerk accounts. Open Inventory to manage stock and movements."
              actionLabel="Open Inventory"
              onAction={() => onNavigate('inventory')}
            />
          ) : recentTransactions.length === 0 ? (
            <EmptyState
              icon={ReceiptIndianRupee}
              title="No transactions yet"
              description="Create your first sale bill or record an expense to see live transaction activity here."
              actionLabel="Create First Bill"
              onAction={() => onNavigate('sales')}
            />
          ) : (
            <div className="divide-y divide-slate-100">
              {recentTransactions.map((tx) => (
                <div key={tx.id} className="py-2.5 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-slate-900 truncate">{tx.title}</div>
                    <div className="text-xs text-slate-500">
                      {tx.type} · {tx.subtitle} · {formatDateIN(tx.date)}
                    </div>
                  </div>
                  <div
                    className={`text-sm font-mono font-semibold tabular-nums shrink-0 ${
                      tx.isCredit ? 'text-emerald-700' : 'text-rose-600'
                    }`}
                  >
                    {tx.isCredit ? '+' : '-'}
                    {formatINR(tx.amount)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
