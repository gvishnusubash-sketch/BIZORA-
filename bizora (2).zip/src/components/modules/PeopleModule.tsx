import React, { useMemo, useState } from 'react';
import {
  Activity,
  CreditCard,
  Edit3,
  Plus,
  Search,
  Shield,
  Trash2,
  UserCheck,
  Users,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useBusinessData } from '../../contexts/BusinessDataContext';
import { formatCount, formatDateIN, formatDateTimeIN, formatINR } from '../../lib/formatters';
import { FIELD_LIMITS, isValidEmail, isValidGstin, isValidPhone } from '../../lib/validation';
import {
  addStaffAndInvite,
  createCustomer,
  recordCustomerPayment,
  removeStaffMember,
  updateCustomer,
  updateStaffProfileAndRole,
} from '../../services/bizoraService';
import type { Customer, NonCreditPaymentMethod, Role, StaffMember } from '../../types/bizora';
import { ConfirmDialog } from '../ui/ConfirmDialog';
import { EmptyState, FormErrorBanner, StatCard, TableSkeleton } from '../ui/DataPrimitives';
import { Modal } from '../ui/Modal';

export function PeopleModule() {
  const { activeBusiness, actor, role, permissions } = useAuth();
  const { customers, sales, payments, staff, activityLogs, loading } = useBusinessData();

  const [tab, setTab] = useState<'customers' | 'staff' | 'activity'>(
    permissions.canViewCustomers ? 'customers' : 'staff'
  );

  // Customers state
  const [custSearch, setCustSearch] = useState('');
  const [custModalOpen, setCustModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [cName, setCName] = useState('');
  const [cPhone, setCPhone] = useState('');
  const [cEmail, setCEmail] = useState('');
  const [cAddress, setCAddress] = useState('');
  const [cGstin, setCGstin] = useState('');
  const [cNotes, setCNotes] = useState('');
  const [custError, setCustError] = useState<string | null>(null);
  const [custSaving, setCustSaving] = useState(false);

  // Customer Detail + Payment Modal
  const [detailCustomer, setDetailCustomer] = useState<Customer | null>(null);
  const [payCustomer, setPayCustomer] = useState<Customer | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState<NonCreditPaymentMethod>('upi');
  const [payNote, setPayNote] = useState('');
  const [payError, setPayError] = useState<string | null>(null);
  const [paying, setPaying] = useState(false);

  // Staff state
  const [staffModalOpen, setStaffModalOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);
  const [sName, setSName] = useState('');
  const [sEmail, setSEmail] = useState('');
  const [sPhone, setSPhone] = useState('');
  const [sRole, setSRole] = useState<Role>('cashier');
  const [sDepartment, setSDepartment] = useState('');
  const [sSalary, setSSalary] = useState('18000');
  const [sStatus, setSStatus] = useState<'active' | 'invited' | 'inactive'>('active');
  const [sInvite, setSInvite] = useState(true);
  const [staffError, setStaffError] = useState<string | null>(null);
  const [staffSaving, setStaffSaving] = useState(false);
  const [deleteStaffTarget, setDeleteStaffTarget] = useState<StaffMember | null>(null);
  const [deletingStaff, setDeletingStaff] = useState(false);

  const filteredCustomers = useMemo(() => {
    const q = custSearch.trim().toLowerCase();
    if (!q) return customers;
    return customers.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        (c.email || '').toLowerCase().includes(q) ||
        (c.gstin || '').toLowerCase().includes(q)
    );
  }, [customers, custSearch]);

  const customerStats = useMemo(() => {
    const totalReceivables = customers.reduce((s, c) => s + c.outstandingBalance, 0);
    const withDues = customers.filter((c) => c.outstandingBalance > 0).length;
    return { totalReceivables, withDues };
  }, [customers]);

  const detailCustomerSales = useMemo(() => {
    if (!detailCustomer) return [];
    return sales.filter((s) => s.customerId === detailCustomer.id);
  }, [sales, detailCustomer]);

  const detailCustomerPayments = useMemo(() => {
    if (!detailCustomer) return [];
    return payments.filter((p) => p.customerId === detailCustomer.id);
  }, [payments, detailCustomer]);

  const openAddCustomer = () => {
    setEditingCustomer(null);
    setCName('');
    setCPhone('');
    setCEmail('');
    setCAddress('');
    setCGstin('');
    setCNotes('');
    setCustError(null);
    setCustModalOpen(true);
  };

  const openEditCustomer = (c: Customer) => {
    setEditingCustomer(c);
    setCName(c.name);
    setCPhone(c.phone);
    setCEmail(c.email || '');
    setCAddress(c.address || '');
    setCGstin(c.gstin || '');
    setCNotes(c.notes || '');
    setCustError(null);
    setCustModalOpen(true);
  };

  const handleSaveCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBusiness || !actor) return;
    setCustError(null);

    if (cName.trim().length < 2) return setCustError('Customer name must be at least 2 characters.');
    if (!isValidPhone(cPhone)) return setCustError('Please enter a valid 6–20 digit phone number.');
    if (cEmail.trim() && !isValidEmail(cEmail)) return setCustError('Please enter a valid email address.');
    if (cGstin.trim() && !isValidGstin(cGstin)) return setCustError('Invalid 15-character GSTIN format.');

    setCustSaving(true);
    try {
      if (editingCustomer) {
        await updateCustomer(activeBusiness.id, editingCustomer.id, actor, {
          name: cName,
          phone: cPhone,
          email: cEmail,
          address: cAddress,
          gstin: cGstin,
          notes: cNotes,
        });
      } else {
        await createCustomer(activeBusiness.id, actor, {
          name: cName,
          phone: cPhone,
          email: cEmail,
          address: cAddress,
          gstin: cGstin,
          notes: cNotes,
        });
      }
      setCustModalOpen(false);
    } catch (err) {
      setCustError(err instanceof Error ? err.message : 'Failed to save customer.');
    } finally {
      setCustSaving(false);
    }
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBusiness || !actor || !payCustomer) return;
    setPayError(null);
    const amt = Number(payAmount);
    if (!Number.isFinite(amt) || amt <= 0) {
      return setPayError('Enter a payment amount greater than ₹0.');
    }
    if (amt > payCustomer.outstandingBalance + 0.01) {
      return setPayError(`Payment exceeds outstanding balance (${formatINR(payCustomer.outstandingBalance, true)}).`);
    }

    setPaying(true);
    try {
      await recordCustomerPayment(activeBusiness.id, actor, {
        customerId: payCustomer.id,
        amount: amt,
        method: payMethod,
        referenceNote: payNote.trim(),
      });
      setPayCustomer(null);
      setPayAmount('');
      setPayNote('');
    } catch (err) {
      setPayError(err instanceof Error ? err.message : 'Could not record payment.');
    } finally {
      setPaying(false);
    }
  };

  const openAddStaff = () => {
    setEditingStaff(null);
    setSName('');
    setSEmail('');
    setSPhone('');
    setSRole('cashier');
    setSDepartment('POS & Billing');
    setSSalary('18000');
    setSStatus('active');
    setSInvite(true);
    setStaffError(null);
    setStaffModalOpen(true);
  };

  const openEditStaff = (s: StaffMember) => {
    setEditingStaff(s);
    setSName(s.name);
    setSEmail(s.email);
    setSPhone(s.phone || '');
    setSRole(s.role);
    setSDepartment(s.department || '');
    setSSalary(String(s.monthlySalary));
    setSStatus(s.status);
    setSInvite(false);
    setStaffError(null);
    setStaffModalOpen(true);
  };

  const handleSaveStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBusiness || !actor) return;
    setStaffError(null);

    if (sName.trim().length < 2) return setStaffError('Employee name must be at least 2 characters.');
    if (!isValidEmail(sEmail)) return setStaffError('A valid email address is required.');
    if (sPhone.trim() && !isValidPhone(sPhone)) return setStaffError('Invalid phone format.');
    const sal = Number(sSalary);
    if (!Number.isFinite(sal) || sal < 0) return setStaffError('Monthly salary must be 0 or greater.');

    setStaffSaving(true);
    try {
      if (editingStaff) {
        await updateStaffProfileAndRole(activeBusiness.id, editingStaff, actor, {
          name: sName,
          phone: sPhone,
          role: sRole,
          department: sDepartment,
          monthlySalary: sal,
          status: sStatus,
        });
      } else {
        await addStaffAndInvite(activeBusiness.id, activeBusiness.name, actor, {
          name: sName,
          email: sEmail,
          phone: sPhone,
          role: sRole === 'owner' ? 'manager' : sRole,
          department: sDepartment,
          monthlySalary: sal,
          sendPortalInvite: sInvite,
        });
      }
      setStaffModalOpen(false);
    } catch (err) {
      setStaffError(err instanceof Error ? err.message : 'Could not save employee record.');
    } finally {
      setStaffSaving(false);
    }
  };

  const handleDeleteStaff = async () => {
    if (!activeBusiness || !actor || !deleteStaffTarget) return;
    setDeletingStaff(true);
    try {
      await removeStaffMember(activeBusiness.id, deleteStaffTarget, actor);
      setDeleteStaffTarget(null);
    } finally {
      setDeletingStaff(false);
    }
  };

  if (loading) {
    return <TableSkeleton rows={6} />;
  }

  return (
    <div className="space-y-5">
      {/* Sub-navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex items-center p-1 bg-slate-200/70 rounded-lg">
          {permissions.canViewCustomers && (
            <button
              type="button"
              onClick={() => setTab('customers')}
              className={`min-h-[36px] px-3.5 py-1.5 text-xs font-medium rounded-md inline-flex items-center gap-1.5 cursor-pointer ${
                tab === 'customers' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Customers ({customers.length})</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => setTab('staff')}
            className={`min-h-[36px] px-3.5 py-1.5 text-xs font-medium rounded-md inline-flex items-center gap-1.5 cursor-pointer ${
              tab === 'staff' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Staff & Roles</span>
          </button>
          {permissions.canManageStaff && (
            <button
              type="button"
              onClick={() => setTab('activity')}
              className={`min-h-[36px] px-3.5 py-1.5 text-xs font-medium rounded-md inline-flex items-center gap-1.5 cursor-pointer ${
                tab === 'activity' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Activity Log</span>
            </button>
          )}
        </div>
      </div>

      {/* CUSTOMERS TAB */}
      {tab === 'customers' && permissions.canViewCustomers && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            <StatCard label="Registered Customers" value={formatCount(customers.length)} subtext="Active credit & retail profiles" />
            <StatCard
              label="Total Outstanding"
              value={formatINR(customerStats.totalReceivables)}
              subtext="Pending collections"
              tone={customerStats.totalReceivables > 0 ? 'amber' : 'emerald'}
            />
            <StatCard
              label="Accounts with Dues"
              value={formatCount(customerStats.withDues)}
              subtext="Customers with open credit"
            />
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={custSearch}
                onChange={(e) => setCustSearch(e.target.value)}
                placeholder="Search customer name, phone, GSTIN..."
                className="w-full min-h-[40px] pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 bg-white text-sm"
              />
            </div>
            <button
              type="button"
              onClick={openAddCustomer}
              className="min-h-[40px] px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-medium inline-flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Add Customer</span>
            </button>
          </div>

          {filteredCustomers.length === 0 ? (
            <EmptyState
              icon={Users}
              title={customers.length === 0 ? 'No customers added yet' : 'No matching customers'}
              description="Save regular shoppers and wholesale buyers to track their purchase history and credit balances."
              actionLabel={customers.length === 0 ? 'Add First Customer' : undefined}
              onAction={customers.length === 0 ? openAddCustomer : undefined}
            />
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500">
                      <th className="py-3 px-4">Customer</th>
                      <th className="py-3 px-4">Contact</th>
                      <th className="py-3 px-4 text-right">Total Purchases</th>
                      <th className="py-3 px-4 text-right">Outstanding</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {filteredCustomers.map((c) => (
                      <tr key={c.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4">
                          <button
                            type="button"
                            onClick={() => setDetailCustomer(c)}
                            className="font-semibold text-slate-900 hover:text-emerald-700 text-left cursor-pointer"
                          >
                            {c.name}
                          </button>
                          {c.gstin && <div className="text-[11px] font-mono text-slate-400">GSTIN: {c.gstin}</div>}
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-600">
                          <div className="font-mono">{c.phone}</div>
                          {c.email && <div className="text-slate-400">{c.email}</div>}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800">
                          {formatINR(c.totalPurchases)}
                        </td>
                        <td
                          className={`py-3 px-4 text-right font-mono font-semibold tabular-nums ${
                            c.outstandingBalance > 0 ? 'text-amber-700' : 'text-emerald-700'
                          }`}
                        >
                          {formatINR(c.outstandingBalance)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="inline-flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => setDetailCustomer(c)}
                              className="min-h-[34px] px-2.5 py-1 rounded-md border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-100 cursor-pointer"
                            >
                              History
                            </button>
                            {c.outstandingBalance > 0 && (
                              <button
                                type="button"
                                onClick={() => {
                                  setPayCustomer(c);
                                  setPayAmount(String(c.outstandingBalance));
                                  setPayMethod('upi');
                                  setPayNote('');
                                  setPayError(null);
                                }}
                                className="min-h-[34px] px-2.5 py-1 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium cursor-pointer"
                              >
                                Receive
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => openEditCustomer(c)}
                              title="Edit customer"
                              className="min-w-[34px] min-h-[34px] rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 inline-flex items-center justify-center cursor-pointer"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* STAFF & ACCESS TAB */}
      {tab === 'staff' && (
        <div className="space-y-5">
          {!permissions.canManageStaff ? (
            <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-3">
              <div className="flex items-center gap-2.5">
                <UserCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-semibold text-slate-900">Your Access Profile</h3>
              </div>
              <p className="text-sm text-slate-600">
                You are signed in as <strong className="text-slate-900">{actor?.name}</strong> ({actor?.email}) with the{' '}
                <strong className="capitalize text-emerald-700">{role}</strong> role.
              </p>
              <p className="text-xs text-slate-500">
                Staff directory, salary details, and employee management are restricted to Business Owners and Managers.
              </p>
            </div>
          ) : (
            <>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-semibold text-slate-900">Team Directory & Role Access</h3>
                  <p className="text-xs text-slate-500">
                    Server-enforced permissions per role: Owner, Manager, Cashier, Inventory Clerk
                  </p>
                </div>
                <button
                  type="button"
                  onClick={openAddStaff}
                  className="min-h-[40px] px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-medium inline-flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Staff Member</span>
                </button>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500">
                        <th className="py-3 px-4">Employee</th>
                        <th className="py-3 px-4">Role & Dept</th>
                        <th className="py-3 px-4 text-right">Monthly Salary</th>
                        <th className="py-3 px-4">Status</th>
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-sm">
                      {staff.map((s) => (
                        <tr key={s.id} className="hover:bg-slate-50/70">
                          <td className="py-3 px-4">
                            <div className="font-semibold text-slate-900">{s.name}</div>
                            <div className="text-xs text-slate-500">
                              {s.email}
                              {s.phone ? ` · ${s.phone}` : ''}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-xs">
                            <div className="font-semibold capitalize text-slate-800">{s.role}</div>
                            <div className="text-slate-400">{s.department || 'General'}</div>
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800">
                            {s.monthlySalary > 0 ? formatINR(s.monthlySalary) : '—'}
                          </td>
                          <td className="py-3 px-4 text-xs capitalize">
                            <span
                              className={`font-medium ${
                                s.status === 'active'
                                  ? 'text-emerald-700'
                                  : s.status === 'invited'
                                    ? 'text-amber-700'
                                    : 'text-slate-400'
                              }`}
                            >
                              {s.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="inline-flex items-center justify-end gap-1">
                              <button
                                type="button"
                                onClick={() => openEditStaff(s)}
                                title="Edit staff member"
                                className="min-w-[34px] min-h-[34px] rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 inline-flex items-center justify-center cursor-pointer"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              {s.role !== 'owner' && role === 'owner' && (
                                <button
                                  type="button"
                                  onClick={() => setDeleteStaffTarget(s)}
                                  title="Remove staff"
                                  className="min-w-[34px] min-h-[34px] rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 inline-flex items-center justify-center cursor-pointer"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* STAFF ACTIVITY LOGS TAB */}
      {tab === 'activity' && permissions.canManageStaff && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {activityLogs.length === 0 ? (
            <EmptyState
              icon={Activity}
              title="No activity logs yet"
              description="Staff billing, stock adjustments, and customer updates are logged here automatically."
            />
          ) : (
            <div className="divide-y divide-slate-100">
              {activityLogs.slice(0, 60).map((log) => (
                <div key={log.id} className="px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-sm text-slate-900">{log.summary}</div>
                    <div className="text-xs text-slate-500">
                      {log.actorName} ({log.actorRole}) · {log.module} · {log.action}
                    </div>
                  </div>
                  <div className="text-xs font-mono text-slate-400 shrink-0">
                    {formatDateTimeIN(log.createdAt)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Add/Edit Customer Modal */}
      <Modal
        open={custModalOpen}
        onClose={() => setCustModalOpen(false)}
        title={editingCustomer ? 'Edit Customer Profile' : 'Add New Customer'}
      >
        <form onSubmit={handleSaveCustomer} className="space-y-4">
          <FormErrorBanner message={custError} />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">Full Name / Business Name *</label>
              <input
                type="text"
                required
                maxLength={FIELD_LIMITS.customerName.max}
                value={cName}
                onChange={(e) => setCName(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Phone *</label>
              <input
                type="tel"
                required
                maxLength={FIELD_LIMITS.phone.max}
                value={cPhone}
                onChange={(e) => setCPhone(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Email</label>
              <input
                type="email"
                maxLength={FIELD_LIMITS.email.max}
                value={cEmail}
                onChange={(e) => setCEmail(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">Address</label>
              <input
                type="text"
                maxLength={FIELD_LIMITS.address.max}
                value={cAddress}
                onChange={(e) => setCAddress(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Customer GSTIN</label>
              <input
                type="text"
                maxLength={15}
                value={cGstin}
                onChange={(e) => setCGstin(e.target.value.toUpperCase())}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono uppercase"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Notes</label>
              <input
                type="text"
                maxLength={FIELD_LIMITS.notes.max}
                value={cNotes}
                onChange={(e) => setCNotes(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCustModalOpen(false)}
              className="min-h-[40px] px-4 rounded-lg border border-slate-200 text-sm cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={custSaving}
              className="min-h-[40px] px-5 rounded-lg bg-emerald-600 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
            >
              {custSaving ? 'Saving...' : 'Save Customer'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Customer Purchase & Payment History Modal */}
      <Modal
        open={Boolean(detailCustomer)}
        onClose={() => setDetailCustomer(null)}
        title={detailCustomer?.name || 'Customer Ledger'}
        subtitle={`${detailCustomer?.phone || ''}${detailCustomer?.address ? ` · ${detailCustomer.address}` : ''}`}
        maxWidthClass="sm:max-w-2xl"
      >
        {detailCustomer && (
          <div className="space-y-5">
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-[11px] text-slate-500">Total Billed</div>
                <div className="text-sm font-mono font-bold text-slate-900 mt-0.5">
                  {formatINR(detailCustomer.totalPurchases)}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-[11px] text-slate-500">Total Paid</div>
                <div className="text-sm font-mono font-bold text-emerald-700 mt-0.5">
                  {formatINR(detailCustomer.totalPaid)}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-[11px] text-slate-500">Balance Due</div>
                <div className="text-sm font-mono font-bold text-amber-700 mt-0.5">
                  {formatINR(detailCustomer.outstandingBalance)}
                </div>
              </div>
            </div>

            {detailCustomer.outstandingBalance > 0 && (
              <button
                type="button"
                onClick={() => {
                  const target = detailCustomer;
                  setDetailCustomer(null);
                  setPayCustomer(target);
                  setPayAmount(String(target.outstandingBalance));
                  setPayMethod('upi');
                  setPayNote('');
                  setPayError(null);
                }}
                className="w-full min-h-[42px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <CreditCard className="w-4 h-4" />
                <span>Record Payment Against Balance</span>
              </button>
            )}

            <div className="space-y-2">
              <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                Purchase History ({detailCustomerSales.length})
              </h4>
              {detailCustomerSales.length === 0 ? (
                <p className="text-xs text-slate-400">No invoices recorded for this customer yet.</p>
              ) : (
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl">
                  {detailCustomerSales.map((s) => (
                    <div key={s.id} className="px-3.5 py-2.5 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-mono font-semibold text-slate-900">{s.invoiceNumber}</span>
                        <span className="text-slate-500"> · {formatDateIN(s.saleDate)} · {s.status}</span>
                      </div>
                      <div className="font-mono text-right">
                        <span className="font-semibold text-slate-900">{formatINR(s.grandTotal)}</span>
                        {s.balanceDue > 0 && (
                          <span className="text-amber-700 ml-2">(Due {formatINR(s.balanceDue)})</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                Payment Collections ({detailCustomerPayments.length})
              </h4>
              {detailCustomerPayments.length === 0 ? (
                <p className="text-xs text-slate-400">No standalone payments logged yet.</p>
              ) : (
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl">
                  {detailCustomerPayments.map((p) => (
                    <div key={p.id} className="px-3.5 py-2.5 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-medium text-slate-900 uppercase">{p.method}</span>
                        <span className="text-slate-500"> · {formatDateIN(p.paymentDate)}</span>
                        {p.referenceNote && <div className="text-slate-400">{p.referenceNote}</div>}
                      </div>
                      <span className="font-mono font-semibold text-emerald-700">
                        +{formatINR(p.amount, true)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* Record Customer Payment Modal */}
      <Modal
        open={Boolean(payCustomer)}
        onClose={() => setPayCustomer(null)}
        title={`Receive Payment · ${payCustomer?.name || ''}`}
        subtitle={`Outstanding balance: ${formatINR(payCustomer?.outstandingBalance || 0, true)}`}
      >
        <form onSubmit={handleRecordPayment} className="space-y-4">
          <FormErrorBanner message={payError} />
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Amount Received (₹) *</label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              max={payCustomer?.outstandingBalance}
              required
              value={payAmount}
              onChange={(e) => setPayAmount(e.target.value)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Method</label>
            <select
              value={payMethod}
              onChange={(e) => setPayMethod(e.target.value as NonCreditPaymentMethod)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white"
            >
              <option value="upi">UPI</option>
              <option value="cash">Cash</option>
              <option value="card">Card</option>
              <option value="bank_transfer">Bank Transfer</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Reference / Note</label>
            <input
              type="text"
              maxLength={200}
              value={payNote}
              onChange={(e) => setPayNote(e.target.value)}
              placeholder="Transaction ID or note"
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setPayCustomer(null)}
              className="min-h-[40px] px-4 rounded-lg border border-slate-200 text-sm cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={paying}
              className="min-h-[40px] px-5 rounded-lg bg-emerald-600 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
            >
              {paying ? 'Saving...' : 'Confirm Payment'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Add/Edit Staff Modal */}
      <Modal
        open={staffModalOpen}
        onClose={() => setStaffModalOpen(false)}
        title={editingStaff ? 'Edit Staff Member' : 'Add Staff Member'}
        subtitle="Configure employee profile and role-based access"
      >
        <form onSubmit={handleSaveStaff} className="space-y-4">
          <FormErrorBanner message={staffError} />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">Employee Name *</label>
              <input
                type="text"
                required
                maxLength={FIELD_LIMITS.staffName.max}
                value={sName}
                onChange={(e) => setSName(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">Google Email Address *</label>
              <input
                type="email"
                required
                disabled={Boolean(editingStaff)}
                maxLength={FIELD_LIMITS.email.max}
                value={sEmail}
                onChange={(e) => setSEmail(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm disabled:bg-slate-50"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Phone</label>
              <input
                type="tel"
                maxLength={FIELD_LIMITS.phone.max}
                value={sPhone}
                onChange={(e) => setSPhone(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Role *</label>
              <select
                value={sRole}
                disabled={editingStaff?.role === 'owner'}
                onChange={(e) => setSRole(e.target.value as Role)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white disabled:bg-slate-50"
              >
                {editingStaff?.role === 'owner' && <option value="owner">Owner</option>}
                <option value="manager">Manager (Operations & Finance)</option>
                <option value="cashier">Cashier (Billing & Customers)</option>
                <option value="inventory">Inventory Clerk (Stock Only)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Department</label>
              <input
                type="text"
                maxLength={FIELD_LIMITS.department.max}
                value={sDepartment}
                onChange={(e) => setSDepartment(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Monthly Salary (₹)</label>
              <input
                type="number"
                min="0"
                step="100"
                value={sSalary}
                onChange={(e) => setSSalary(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono"
              />
            </div>

            {editingStaff && editingStaff.role !== 'owner' && (
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-700 mb-1">Account Status</label>
                <select
                  value={sStatus}
                  onChange={(e) => setSStatus(e.target.value as 'active' | 'invited' | 'inactive')}
                  className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white"
                >
                  <option value="active">Active</option>
                  <option value="invited">Invited</option>
                  <option value="inactive">Inactive / Suspended</option>
                </select>
              </div>
            )}

            {!editingStaff && (
              <div className="sm:col-span-2">
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={sInvite}
                    onChange={(e) => setSInvite(e.target.checked)}
                    className="w-4 h-4 accent-emerald-600 rounded"
                  />
                  <span className="text-xs text-slate-700">
                    Send workspace access invite so they can sign in with this Google email
                  </span>
                </label>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setStaffModalOpen(false)}
              className="min-h-[40px] px-4 rounded-lg border border-slate-200 text-sm cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={staffSaving}
              className="min-h-[40px] px-5 rounded-lg bg-emerald-600 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
            >
              {staffSaving ? 'Saving...' : 'Save Staff'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteStaffTarget)}
        title="Remove Staff Member"
        description={`Remove "${deleteStaffTarget?.name}" from your staff directory and revoke workspace access?`}
        confirmLabel="Remove Staff"
        loading={deletingStaff}
        onConfirm={handleDeleteStaff}
        onCancel={() => setDeleteStaffTarget(null)}
      />
    </div>
  );
}
