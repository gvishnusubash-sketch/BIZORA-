import React, { useMemo, useState } from 'react';
import {
  BarChart3,
  Download,
  Plus,
  Trash2,
  TrendingUp,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useBusinessData } from '../../contexts/BusinessDataContext';
import {
  downloadCsv,
  formatCount,
  formatDateIN,
  formatINR,
  toDateObj,
  toInputDateString,
} from '../../lib/formatters';
import { FIELD_LIMITS } from '../../lib/validation';
import { createExpense, deleteExpense } from '../../services/bizoraService';
import type { Expense, ExpenseCategory, NonCreditPaymentMethod } from '../../types/bizora';
import { HorizontalBarBreakdown } from '../ui/Charts';
import { ConfirmDialog } from '../ui/ConfirmDialog';
import { EmptyState, FormErrorBanner, StatCard, TableSkeleton } from '../ui/DataPrimitives';
import { Modal } from '../ui/Modal';

type ReportType =
  | 'daily_sales'
  | 'monthly_sales'
  | 'profit_expenses'
  | 'inventory'
  | 'best_selling'
  | 'customer_purchases'
  | 'outstanding_payments';

const EXPENSE_CATEGORIES: Array<{ id: ExpenseCategory; label: string }> = [
  { id: 'rent', label: 'Shop / Warehouse Rent' },
  { id: 'utilities', label: 'Electricity & Internet' },
  { id: 'salaries', label: 'Staff Salaries' },
  { id: 'inventory_purchase', label: 'Stock / Wholesale Purchase' },
  { id: 'transport', label: 'Transport & Delivery' },
  { id: 'marketing', label: 'Marketing & Packaging' },
  { id: 'maintenance', label: 'Repairs & Maintenance' },
  { id: 'other', label: 'Other Operating Expense' },
];

export function ReportsModule() {
  const { activeBusiness, actor, permissions } = useAuth();
  const { products, sales, expenses, customers, loading } = useBusinessData();

  const [reportType, setReportType] = useState<ReportType>(
    permissions.canViewFinance ? 'daily_sales' : 'inventory'
  );

  // Expense Modal
  const [expModalOpen, setExpModalOpen] = useState(false);
  const [expTitle, setExpTitle] = useState('');
  const [expCategory, setExpCategory] = useState<ExpenseCategory>('rent');
  const [expAmount, setExpAmount] = useState('');
  const [expMethod, setExpMethod] = useState<NonCreditPaymentMethod>('upi');
  const [expVendor, setExpVendor] = useState('');
  const [expNotes, setExpNotes] = useState('');
  const [expDate, setExpDate] = useState(() => toInputDateString(new Date()));
  const [expError, setExpError] = useState<string | null>(null);
  const [expSaving, setExpSaving] = useState(false);

  const [deleteExpTarget, setDeleteExpTarget] = useState<Expense | null>(null);
  const [deletingExp, setDeletingExp] = useState(false);

  const completedSales = useMemo(() => sales.filter((s) => s.status === 'completed'), [sales]);

  // 1. Daily Sales Aggregation
  const dailySalesRows = useMemo(() => {
    const map = new Map<
      string,
      { dateKey: string; displayDate: string; orders: number; subtotal: number; discount: number; tax: number; total: number; collected: number }
    >();
    for (const s of completedSales) {
      const dt = toDateObj(s.saleDate);
      const key = toInputDateString(dt);
      const cur = map.get(key) || {
        dateKey: key,
        displayDate: formatDateIN(dt),
        orders: 0,
        subtotal: 0,
        discount: 0,
        tax: 0,
        total: 0,
        collected: 0,
      };
      cur.orders += 1;
      cur.subtotal += s.subtotal;
      cur.discount += s.discountTotal;
      cur.tax += s.taxTotal;
      cur.total += s.grandTotal;
      cur.collected += s.amountPaid;
      map.set(key, cur);
    }
    return Array.from(map.values()).sort((a, b) => b.dateKey.localeCompare(a.dateKey));
  }, [completedSales]);

  // 2. Monthly Sales Aggregation
  const monthlySalesRows = useMemo(() => {
    const map = new Map<
      string,
      { monthKey: string; label: string; orders: number; revenue: number; tax: number; cogs: number; grossProfit: number }
    >();
    for (const s of completedSales) {
      const dt = toDateObj(s.saleDate);
      const key = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}`;
      const label = dt.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
      const cur = map.get(key) || {
        monthKey: key,
        label,
        orders: 0,
        revenue: 0,
        tax: 0,
        cogs: 0,
        grossProfit: 0,
      };
      cur.orders += 1;
      cur.revenue += s.grandTotal;
      cur.tax += s.taxTotal;
      cur.cogs += s.cogsTotal;
      cur.grossProfit += s.grandTotal - s.taxTotal - s.cogsTotal;
      map.set(key, cur);
    }
    return Array.from(map.values()).sort((a, b) => b.monthKey.localeCompare(a.monthKey));
  }, [completedSales]);

  // 3. Profit & Expense Totals
  const profitSummary = useMemo(() => {
    const totalRevenue = completedSales.reduce((s, x) => s + x.grandTotal, 0);
    const totalTax = completedSales.reduce((s, x) => s + x.taxTotal, 0);
    const totalCogs = completedSales.reduce((s, x) => s + x.cogsTotal, 0);
    const totalOpEx = expenses.reduce((s, x) => s + x.amount, 0);
    const grossProfit = totalRevenue - totalTax - totalCogs;
    const netProfit = grossProfit - totalOpEx;

    const expByCatMap = new Map<string, number>();
    for (const e of expenses) {
      const label = EXPENSE_CATEGORIES.find((c) => c.id === e.category)?.label || e.category;
      expByCatMap.set(label, (expByCatMap.get(label) || 0) + e.amount);
    }
    const expByCategory = Array.from(expByCatMap.entries())
      .map(([label, value]) => ({ label, value }))
      .sort((a, b) => b.value - a.value);

    return { totalRevenue, totalTax, totalCogs, totalOpEx, grossProfit, netProfit, expByCategory };
  }, [completedSales, expenses]);

  // 4. Best-Selling Products
  const bestSellingRows = useMemo(() => {
    const map = new Map<
      string,
      { productId: string; name: string; sku: string; unitsSold: number; revenue: number; profit: number }
    >();
    for (const s of completedSales) {
      for (const item of s.items) {
        const cur = map.get(item.productId) || {
          productId: item.productId,
          name: item.productName,
          sku: item.sku,
          unitsSold: 0,
          revenue: 0,
          profit: 0,
        };
        const netExclTax = item.lineTotal - item.taxAmount;
        cur.unitsSold += item.quantity;
        cur.revenue += item.lineTotal;
        cur.profit += netExclTax - item.purchasePrice * item.quantity;
        map.set(item.productId, cur);
      }
    }
    return Array.from(map.values()).sort((a, b) => b.revenue - a.revenue);
  }, [completedSales]);

  // 5. Outstanding Customers & Open Invoices
  const outstandingCustomers = useMemo(
    () => customers.filter((c) => c.outstandingBalance > 0).sort((a, b) => b.outstandingBalance - a.outstandingBalance),
    [customers]
  );

  // 6. Data-Driven Business Intelligence (strictly derived from stored Firestore records)
  const biInsights = useMemo(() => {
    if (!permissions.canViewFinance) return [];
    const insights: Array<{ title: string; detail: string }> = [];

    if (completedSales.length === 0 && expenses.length === 0) {
      insights.push({
        title: 'Insufficient transaction history',
        detail: 'Record sales bills and operating expenses to generate trend comparisons, margin drivers, and product velocity metrics.',
      });
      return insights;
    }

    // Period comparison: last 7 days vs prior 7 days
    const now = Date.now();
    const last7Start = now - 7 * 86400000;
    const prev7Start = now - 14 * 86400000;
    const last7Sales = completedSales
      .filter((s) => toDateObj(s.saleDate).getTime() >= last7Start)
      .reduce((sum, s) => sum + s.grandTotal, 0);
    const prev7Sales = completedSales
      .filter((s) => {
        const t = toDateObj(s.saleDate).getTime();
        return t >= prev7Start && t < last7Start;
      })
      .reduce((sum, s) => sum + s.grandTotal, 0);

    if (prev7Sales > 0) {
      const changePct = Math.round(((last7Sales - prev7Sales) / prev7Sales) * 100);
      insights.push({
        title: '7-Day Sales Momentum',
        detail: `Sales over the last 7 days (${formatINR(last7Sales)}) are ${
          changePct >= 0 ? `up ${changePct}%` : `down ${Math.abs(changePct)}%`
        } compared to the previous 7-day window (${formatINR(prev7Sales)}).`,
      });
    } else if (last7Sales > 0) {
      insights.push({
        title: 'Recent 7-Day Activity',
        detail: `Recorded ${formatINR(last7Sales)} in completed sales over the last 7 days. No prior-week bills exist yet for week-over-week comparison.`,
      });
    }

    // Margin & Top Product
    if (bestSellingRows.length > 0) {
      const top = bestSellingRows[0];
      const netRev = profitSummary.totalRevenue - profitSummary.totalTax;
      const netMarginPct = netRev > 0 ? ((profitSummary.netProfit / netRev) * 100).toFixed(1) : '0.0';
      insights.push({
        title: 'Top Revenue Product & Net Margin',
        detail: `"${top.name}" leads sales with ${formatCount(top.unitsSold)} units sold (${formatINR(top.revenue)}). Overall net profit margin after COGS and expenses stands at ${netMarginPct}%.`,
      });
    }

    // Top Expense Category
    if (profitSummary.expByCategory.length > 0) {
      const topExp = profitSummary.expByCategory[0];
      const share = profitSummary.totalOpEx > 0 ? Math.round((topExp.value / profitSummary.totalOpEx) * 100) : 0;
      insights.push({
        title: 'Primary Operating Expense Driver',
        detail: `${topExp.label} accounts for ${share}% (${formatINR(topExp.value)}) of your ${formatINR(profitSummary.totalOpEx)} recorded operating expenses.`,
      });
    }

    // Stock & Receivables Risk
    const lowStock = products.filter((p) => p.currentStock <= p.lowStockThreshold);
    const totalDue = outstandingCustomers.reduce((s, c) => s + c.outstandingBalance, 0);
    if (lowStock.length > 0 || totalDue > 0) {
      const parts: string[] = [];
      if (lowStock.length > 0) {
        parts.push(`${lowStock.length} SKU${lowStock.length > 1 ? 's' : ''} at or below reorder level (${lowStock.slice(0, 2).map((p) => p.name).join(', ')})`);
      }
      if (totalDue > 0 && outstandingCustomers[0]) {
        const topDebtor = outstandingCustomers[0];
        const share = Math.round((topDebtor.outstandingBalance / totalDue) * 100);
        parts.push(`${formatINR(totalDue)} in open receivables (${share}% held by ${topDebtor.name})`);
      }
      insights.push({
        title: 'Working Capital & Reorder Watch',
        detail: parts.join('; ') + '.',
      });
    }

    return insights;
  }, [permissions.canViewFinance, completedSales, expenses, bestSellingRows, profitSummary, products, outstandingCustomers]);

  const handleDownloadCsv = () => {
    const stamp = toInputDateString(new Date());
    if (reportType === 'daily_sales') {
      downloadCsv(
        `bizora-daily-sales-${stamp}.csv`,
        ['Date', 'Orders', 'Subtotal (INR)', 'Discounts (INR)', 'Tax (INR)', 'Gross Total (INR)', 'Collected (INR)'],
        dailySalesRows.map((r) => [r.displayDate, r.orders, r.subtotal, r.discount, r.tax, r.total, r.collected])
      );
    } else if (reportType === 'monthly_sales') {
      downloadCsv(
        `bizora-monthly-sales-${stamp}.csv`,
        ['Month', 'Orders', 'Gross Sales (INR)', 'Tax (INR)', 'COGS (INR)', 'Gross Profit (INR)'],
        monthlySalesRows.map((r) => [r.label, r.orders, r.revenue, r.tax, r.cogs, r.grossProfit])
      );
    } else if (reportType === 'profit_expenses') {
      downloadCsv(
        `bizora-expenses-${stamp}.csv`,
        ['Date', 'Title', 'Category', 'Payment Method', 'Vendor', 'Amount (INR)', 'Recorded By'],
        expenses.map((e) => [
          formatDateIN(e.expenseDate),
          e.title,
          e.category,
          e.paymentMethod,
          e.vendorName || '',
          e.amount,
          e.recordedByName,
        ])
      );
    } else if (reportType === 'inventory') {
      downloadCsv(
        `bizora-inventory-${stamp}.csv`,
        ['SKU', 'Name', 'Category', 'Stock', 'Unit', 'Threshold', 'Purchase Price', 'Selling Price', 'Cost Valuation'],
        products.map((p) => [
          p.sku,
          p.name,
          p.category,
          p.currentStock,
          p.unit,
          p.lowStockThreshold,
          p.purchasePrice,
          p.sellingPrice,
          p.currentStock * p.purchasePrice,
        ])
      );
    } else if (reportType === 'best_selling') {
      downloadCsv(
        `bizora-best-selling-${stamp}.csv`,
        ['SKU', 'Product', 'Units Sold', 'Total Revenue (INR)', 'Gross Profit (INR)'],
        bestSellingRows.map((r) => [r.sku, r.name, r.unitsSold, r.revenue, r.profit])
      );
    } else if (reportType === 'customer_purchases') {
      downloadCsv(
        `bizora-customer-purchases-${stamp}.csv`,
        ['Customer', 'Phone', 'GSTIN', 'Total Billed (INR)', 'Total Paid (INR)', 'Outstanding (INR)'],
        customers.map((c) => [c.name, c.phone, c.gstin || '', c.totalPurchases, c.totalPaid, c.outstandingBalance])
      );
    } else if (reportType === 'outstanding_payments') {
      downloadCsv(
        `bizora-outstanding-payments-${stamp}.csv`,
        ['Customer', 'Phone', 'Total Billed (INR)', 'Total Paid (INR)', 'Balance Due (INR)'],
        outstandingCustomers.map((c) => [c.name, c.phone, c.totalPurchases, c.totalPaid, c.outstandingBalance])
      );
    }
  };

  const handleSaveExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBusiness || !actor) return;
    setExpError(null);
    const amt = Number(expAmount);
    if (expTitle.trim().length < 2) return setExpError('Expense title must be at least 2 characters.');
    if (!Number.isFinite(amt) || amt <= 0) return setExpError('Amount must be greater than ₹0.');

    setExpSaving(true);
    try {
      await createExpense(activeBusiness.id, actor, {
        title: expTitle.trim(),
        category: expCategory,
        amount: amt,
        paymentMethod: expMethod,
        vendorName: expVendor.trim(),
        notes: expNotes.trim(),
        expenseDate: new Date(`${expDate}T12:00:00`),
      });
      setExpModalOpen(false);
      setExpTitle('');
      setExpAmount('');
      setExpVendor('');
      setExpNotes('');
    } catch (err) {
      setExpError(err instanceof Error ? err.message : 'Failed to save expense.');
    } finally {
      setExpSaving(false);
    }
  };

  const handleDeleteExpense = async () => {
    if (!activeBusiness || !actor || !deleteExpTarget) return;
    setDeletingExp(true);
    try {
      await deleteExpense(activeBusiness.id, deleteExpTarget, actor);
      setDeleteExpTarget(null);
    } finally {
      setDeletingExp(false);
    }
  };

  if (loading) {
    return <TableSkeleton rows={6} />;
  }

  const availableReports: Array<{ id: ReportType; label: string; visible: boolean }> = [
    { id: 'daily_sales', label: 'Daily Sales', visible: permissions.canViewFinance },
    { id: 'monthly_sales', label: 'Monthly Sales', visible: permissions.canViewFinance },
    { id: 'profit_expenses', label: 'Profit & Expenses', visible: permissions.canViewFinance },
    { id: 'inventory', label: 'Inventory Stock', visible: true },
    { id: 'best_selling', label: 'Best-Selling Products', visible: permissions.canViewFinance },
    { id: 'customer_purchases', label: 'Customer Purchases', visible: permissions.canViewFinance },
    { id: 'outstanding_payments', label: 'Outstanding Dues', visible: permissions.canViewFinance },
  ];

  return (
    <div className="space-y-6">
      {/* Report Selector & Export Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5 bg-slate-200/70 p-1 rounded-xl">
          {availableReports
            .filter((r) => r.visible)
            .map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => setReportType(r.id)}
                className={`min-h-[34px] px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  reportType === r.id ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {r.label}
              </button>
            ))}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {permissions.canViewFinance && (
            <button
              type="button"
              onClick={() => {
                setExpError(null);
                setExpModalOpen(true);
              }}
              className="min-h-[40px] px-3.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs sm:text-sm font-medium text-slate-800 inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4 text-emerald-600" />
              <span>Log Expense</span>
            </button>
          )}
          <button
            type="button"
            onClick={handleDownloadCsv}
            className="min-h-[40px] px-4 py-1.5 rounded-lg bg-[#0B1528] hover:bg-slate-800 text-white text-xs sm:text-sm font-medium inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download CSV</span>
          </button>
        </div>
      </div>

      {/* Business Intelligence Panel (Factual, Stored-Data Driven) */}
      {permissions.canViewFinance && biInsights.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-semibold text-slate-900">Business Intelligence Summary</h3>
            <span className="text-xs text-slate-400">· Computed from stored records</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
            {biInsights.map((ins) => (
              <div key={ins.title} className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                <div className="text-xs font-semibold text-slate-900">{ins.title}</div>
                <p className="text-xs text-slate-600 leading-relaxed">{ins.detail}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Report Tables */}
      {reportType === 'daily_sales' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {dailySalesRows.length === 0 ? (
            <EmptyState icon={BarChart3} title="No daily sales data" description="Completed invoices will appear grouped by day here." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500">
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4 text-right">Orders</th>
                    <th className="py-3 px-4 text-right">Subtotal</th>
                    <th className="py-3 px-4 text-right">Discounts</th>
                    <th className="py-3 px-4 text-right">Tax</th>
                    <th className="py-3 px-4 text-right">Gross Sales</th>
                    <th className="py-3 px-4 text-right">Collected</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {dailySalesRows.map((r) => (
                    <tr key={r.dateKey} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-medium text-slate-900">{r.displayDate}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">{r.orders}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">{formatINR(r.subtotal)}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-500">{formatINR(r.discount)}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-500">{formatINR(r.tax)}</td>
                      <td className="py-3 px-4 text-right font-mono font-semibold tabular-nums text-slate-900">{formatINR(r.total)}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-700">{formatINR(r.collected)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {reportType === 'monthly_sales' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {monthlySalesRows.length === 0 ? (
            <EmptyState icon={BarChart3} title="No monthly sales data" description="Monthly revenue and gross profit summaries appear once bills are recorded." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500">
                    <th className="py-3 px-4">Month</th>
                    <th className="py-3 px-4 text-right">Orders</th>
                    <th className="py-3 px-4 text-right">Gross Sales</th>
                    <th className="py-3 px-4 text-right">GST</th>
                    <th className="py-3 px-4 text-right">COGS</th>
                    <th className="py-3 px-4 text-right">Gross Profit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {monthlySalesRows.map((r) => (
                    <tr key={r.monthKey}>
                      <td className="py-3 px-4 font-medium text-slate-900">{r.label}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">{r.orders}</td>
                      <td className="py-3 px-4 text-right font-mono font-semibold tabular-nums">{formatINR(r.revenue)}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-500">{formatINR(r.tax)}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-600">{formatINR(r.cogs)}</td>
                      <td className="py-3 px-4 text-right font-mono font-semibold tabular-nums text-emerald-700">{formatINR(r.grossProfit)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {reportType === 'profit_expenses' && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            <StatCard label="Revenue (Incl. GST)" value={formatINR(profitSummary.totalRevenue)} subtext={`Tax: ${formatINR(profitSummary.totalTax)}`} />
            <StatCard label="Cost of Goods Sold" value={formatINR(profitSummary.totalCogs)} subtext={`Gross profit: ${formatINR(profitSummary.grossProfit)}`} />
            <StatCard label="Operating Expenses" value={formatINR(profitSummary.totalOpEx)} subtext={`${expenses.length} recorded entries`} />
            <StatCard
              label="Net Profit"
              value={formatINR(profitSummary.netProfit)}
              subtext="Gross profit minus expenses"
              tone={profitSummary.netProfit >= 0 ? 'emerald' : 'rose'}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <h3 className="text-sm font-semibold text-slate-900">Expenses by Category</h3>
              <HorizontalBarBreakdown items={profitSummary.expByCategory} emptyText="No operating expenses logged yet." />
            </div>

            <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-slate-900">Expense Ledger</h3>
                <button
                  type="button"
                  onClick={() => setExpModalOpen(true)}
                  className="text-xs font-semibold text-emerald-700 hover:underline cursor-pointer"
                >
                  + Add Expense
                </button>
              </div>
              {expenses.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">No expenses logged yet.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500">
                        <th className="py-2.5 px-4">Date</th>
                        <th className="py-2.5 px-4">Title & Vendor</th>
                        <th className="py-2.5 px-4">Category</th>
                        <th className="py-2.5 px-4 text-right">Amount</th>
                        {actor?.role === 'owner' && <th className="py-2.5 px-4 text-right">Action</th>}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-sm">
                      {expenses.map((e) => (
                        <tr key={e.id}>
                          <td className="py-2.5 px-4 text-xs font-mono text-slate-500 whitespace-nowrap">
                            {formatDateIN(e.expenseDate)}
                          </td>
                          <td className="py-2.5 px-4">
                            <div className="font-medium text-slate-900">{e.title}</div>
                            {e.vendorName && <div className="text-xs text-slate-400">{e.vendorName}</div>}
                          </td>
                          <td className="py-2.5 px-4 text-xs capitalize text-slate-600">{e.category.replace('_', ' ')}</td>
                          <td className="py-2.5 px-4 text-right font-mono font-semibold tabular-nums text-rose-600">
                            {formatINR(e.amount)}
                          </td>
                          {actor?.role === 'owner' && (
                            <td className="py-2.5 px-4 text-right">
                              <button
                                type="button"
                                onClick={() => setDeleteExpTarget(e)}
                                aria-label={`Delete expense ${e.title}`}
                                className="min-w-[32px] min-h-[32px] rounded text-slate-400 hover:text-rose-600 inline-flex items-center justify-center cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {reportType === 'inventory' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500">
                  <th className="py-3 px-4">SKU & Product</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4 text-right">Stock</th>
                  <th className="py-3 px-4 text-right">Cost Value</th>
                  <th className="py-3 px-4 text-right">Retail Value</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {products.map((p) => {
                  const status =
                    p.currentStock === 0
                      ? 'Out of stock'
                      : p.currentStock <= p.lowStockThreshold
                        ? 'Low stock'
                        : 'Healthy';
                  return (
                    <tr key={p.id}>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">{p.name}</div>
                        <div className="text-xs font-mono text-slate-400">{p.sku}</div>
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-600">{p.category}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {p.currentStock} {p.unit}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {formatINR(p.currentStock * p.purchasePrice)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold">
                        {formatINR(p.currentStock * p.sellingPrice)}
                      </td>
                      <td
                        className={`py-3 px-4 text-xs font-medium ${
                          status === 'Out of stock'
                            ? 'text-rose-600'
                            : status === 'Low stock'
                              ? 'text-amber-700'
                              : 'text-emerald-700'
                        }`}
                      >
                        {status}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {reportType === 'best_selling' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {bestSellingRows.length === 0 ? (
            <EmptyState icon={BarChart3} title="No product sales yet" description="Best-selling SKU rankings are calculated from completed invoices." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500">
                    <th className="py-3 px-4">Rank & Product</th>
                    <th className="py-3 px-4 text-right">Units Sold</th>
                    <th className="py-3 px-4 text-right">Revenue</th>
                    <th className="py-3 px-4 text-right">Gross Profit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {bestSellingRows.map((r, i) => (
                    <tr key={r.productId}>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">
                          {i + 1}. {r.name}
                        </div>
                        <div className="text-xs font-mono text-slate-400">{r.sku}</div>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-semibold tabular-nums">{r.unitsSold}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">{formatINR(r.revenue)}</td>
                      <td className="py-3 px-4 text-right font-mono font-semibold tabular-nums text-emerald-700">
                        {formatINR(r.profit)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {reportType === 'customer_purchases' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500">
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Phone</th>
                  <th className="py-3 px-4 text-right">Total Billed</th>
                  <th className="py-3 px-4 text-right">Total Paid</th>
                  <th className="py-3 px-4 text-right">Outstanding</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {[...customers]
                  .sort((a, b) => b.totalPurchases - a.totalPurchases)
                  .map((c) => (
                    <tr key={c.id}>
                      <td className="py-3 px-4 font-medium text-slate-900">{c.name}</td>
                      <td className="py-3 px-4 text-xs font-mono text-slate-500">{c.phone}</td>
                      <td className="py-3 px-4 text-right font-mono font-semibold tabular-nums">{formatINR(c.totalPurchases)}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-700">{formatINR(c.totalPaid)}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-amber-700">{formatINR(c.outstandingBalance)}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {reportType === 'outstanding_payments' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {outstandingCustomers.length === 0 ? (
            <EmptyState icon={BarChart3} title="Zero outstanding dues" description="All customer accounts are settled." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500">
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Phone</th>
                    <th className="py-3 px-4 text-right">Total Billed</th>
                    <th className="py-3 px-4 text-right">Paid</th>
                    <th className="py-3 px-4 text-right">Balance Due</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {outstandingCustomers.map((c) => (
                    <tr key={c.id}>
                      <td className="py-3 px-4 font-medium text-slate-900">{c.name}</td>
                      <td className="py-3 px-4 text-xs font-mono text-slate-500">{c.phone}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">{formatINR(c.totalPurchases)}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-700">{formatINR(c.totalPaid)}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-amber-700">
                        {formatINR(c.outstandingBalance)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Log Expense Modal */}
      <Modal
        open={expModalOpen}
        onClose={() => setExpModalOpen(false)}
        title="Record Business Expense"
        subtitle="Deducted from Gross Profit to calculate Net Profit"
      >
        <form onSubmit={handleSaveExpense} className="space-y-4">
          <FormErrorBanner message={expError} />
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Expense Title *</label>
            <input
              type="text"
              required
              maxLength={FIELD_LIMITS.expenseTitle.max}
              value={expTitle}
              onChange={(e) => setExpTitle(e.target.value)}
              placeholder="e.g. Shop Electricity Bill"
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Category *</label>
              <select
                value={expCategory}
                onChange={(e) => setExpCategory(e.target.value as ExpenseCategory)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white"
              >
                {EXPENSE_CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Amount (₹) *</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                required
                value={expAmount}
                onChange={(e) => setExpAmount(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Payment Method</label>
              <select
                value={expMethod}
                onChange={(e) => setExpMethod(e.target.value as NonCreditPaymentMethod)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white"
              >
                <option value="upi">UPI</option>
                <option value="cash">Cash</option>
                <option value="bank_transfer">Bank Transfer</option>
                <option value="card">Card</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Date *</label>
              <input
                type="date"
                required
                value={expDate}
                onChange={(e) => setExpDate(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Vendor / Payee</label>
            <input
              type="text"
              maxLength={FIELD_LIMITS.vendorName.max}
              value={expVendor}
              onChange={(e) => setExpVendor(e.target.value)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setExpModalOpen(false)}
              className="min-h-[40px] px-4 rounded-lg border border-slate-200 text-sm cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={expSaving}
              className="min-h-[40px] px-5 rounded-lg bg-emerald-600 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
            >
              {expSaving ? 'Saving...' : 'Save Expense'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteExpTarget)}
        title="Delete Expense Record"
        description={`Delete "${deleteExpTarget?.title}" (${formatINR(deleteExpTarget?.amount || 0)}) from your ledger?`}
        confirmLabel="Delete Expense"
        loading={deletingExp}
        onConfirm={handleDeleteExpense}
        onCancel={() => setDeleteExpTarget(null)}
      />
    </div>
  );
}
