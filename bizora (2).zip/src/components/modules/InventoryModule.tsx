import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowUpDown,
  Edit3,
  History,
  Package,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useBusinessData } from '../../contexts/BusinessDataContext';
import { formatCount, formatDateTimeIN, formatINR } from '../../lib/formatters';
import { FIELD_LIMITS } from '../../lib/validation';
import {
  adjustProductStock,
  createProduct,
  deleteProduct,
  updateProductDetails,
} from '../../services/bizoraService';
import type { Product } from '../../types/bizora';
import { ConfirmDialog } from '../ui/ConfirmDialog';
import { EmptyState, FormErrorBanner, StatCard, TableSkeleton } from '../ui/DataPrimitives';
import { Modal } from '../ui/Modal';

const DEFAULT_CATEGORIES = [
  'Chargers & Cables',
  'Audio & Earbuds',
  'Power Banks',
  'Screen Protection',
  'Cases & Covers',
  'Stands & Mounts',
  'Storage',
  'Smartphones & Tablets',
  'General Merchandise',
];

export function InventoryModule() {
  const { activeBusiness, actor, permissions } = useAuth();
  const { products, stockMovements, loading } = useBusinessData();

  const [view, setView] = useState<'catalog' | 'history'>('catalog');
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [lowStockOnly, setLowStockOnly] = useState(false);

  // Product Form Modal
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [category, setCategory] = useState(DEFAULT_CATEGORIES[0]);
  const [brand, setBrand] = useState('');
  const [unit, setUnit] = useState('pcs');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [gstRate, setGstRate] = useState<0 | 5 | 12 | 18 | 28>(18);
  const [currentStock, setCurrentStock] = useState('0');
  const [lowStockThreshold, setLowStockThreshold] = useState('5');
  const [supplierName, setSupplierName] = useState('');
  const [supplierPhone, setSupplierPhone] = useState('');

  // Stock Adjustment Modal
  const [adjustTarget, setAdjustTarget] = useState<Product | null>(null);
  const [adjustType, setAdjustType] = useState<'purchase' | 'adjustment_in' | 'adjustment_out'>('purchase');
  const [adjustQty, setAdjustQty] = useState('');
  const [adjustReason, setAdjustReason] = useState('');
  const [adjustError, setAdjustError] = useState<string | null>(null);
  const [adjusting, setAdjusting] = useState(false);

  // Delete Confirmation
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null);
  const [deleting, setDeleting] = useState(false);

  const categories = useMemo(() => {
    const set = new Set<string>(products.map((p) => p.category));
    return ['all', ...Array.from(set).sort()];
  }, [products]);

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products.filter((p) => {
      if (categoryFilter !== 'all' && p.category !== categoryFilter) return false;
      if (lowStockOnly && p.currentStock > p.lowStockThreshold) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        (p.brand || '').toLowerCase().includes(q) ||
        (p.supplierName || '').toLowerCase().includes(q)
      );
    });
  }, [products, search, categoryFilter, lowStockOnly]);

  const filteredMovements = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return stockMovements;
    return stockMovements.filter(
      (m) =>
        m.productName.toLowerCase().includes(q) ||
        m.sku.toLowerCase().includes(q) ||
        (m.reason || '').toLowerCase().includes(q) ||
        (m.referenceId || '').toLowerCase().includes(q)
    );
  }, [stockMovements, search]);

  const summary = useMemo(() => {
    const totalUnits = products.reduce((s, p) => s + p.currentStock, 0);
    const stockCostValue = products.reduce((s, p) => s + p.currentStock * p.purchasePrice, 0);
    const lowCount = products.filter((p) => p.currentStock <= p.lowStockThreshold).length;
    return { totalUnits, stockCostValue, lowCount };
  }, [products]);

  const openAddModal = () => {
    setEditingProduct(null);
    setName('');
    setSku('');
    setCategory(DEFAULT_CATEGORIES[0]);
    setBrand('');
    setUnit('pcs');
    setPurchasePrice('');
    setSellingPrice('');
    setGstRate(18);
    setCurrentStock('0');
    setLowStockThreshold('5');
    setSupplierName('');
    setSupplierPhone('');
    setFormError(null);
    setProductModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setName(p.name);
    setSku(p.sku);
    setCategory(p.category);
    setBrand(p.brand || '');
    setUnit(p.unit);
    setPurchasePrice(String(p.purchasePrice));
    setSellingPrice(String(p.sellingPrice));
    setGstRate(p.gstRate);
    setCurrentStock(String(p.currentStock));
    setLowStockThreshold(String(p.lowStockThreshold));
    setSupplierName(p.supplierName || '');
    setSupplierPhone(p.supplierPhone || '');
    setFormError(null);
    setProductModalOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBusiness || !actor) return;
    setFormError(null);

    const pp = Number(purchasePrice);
    const sp = Number(sellingPrice);
    const st = Number(currentStock);
    const low = Number(lowStockThreshold);

    if (!name.trim()) return setFormError('Product name is required.');
    if (!sku.trim()) return setFormError('SKU code is required.');
    if (!category.trim()) return setFormError('Category is required.');
    if (Number.isNaN(pp) || pp < 0) return setFormError('Purchase price must be 0 or greater.');
    if (Number.isNaN(sp) || sp < 0) return setFormError('Selling price must be 0 or greater.');
    if (!editingProduct && (Number.isNaN(st) || st < 0 || !Number.isInteger(st))) {
      return setFormError('Initial stock must be a whole number (0 or greater).');
    }
    if (Number.isNaN(low) || low < 0 || !Number.isInteger(low)) {
      return setFormError('Low-stock threshold must be a whole number (0 or greater).');
    }

    const duplicateSku = products.some(
      (p) => p.sku.toUpperCase() === sku.trim().toUpperCase() && p.id !== editingProduct?.id
    );
    if (duplicateSku) {
      return setFormError(`SKU "${sku.trim().toUpperCase()}" already exists in your catalog.`);
    }

    setSaving(true);
    try {
      if (editingProduct) {
        await updateProductDetails(activeBusiness.id, editingProduct.id, actor, {
          name,
          sku,
          category,
          brand,
          unit,
          purchasePrice: pp,
          sellingPrice: sp,
          gstRate,
          lowStockThreshold: low,
          supplierName,
          supplierPhone,
        });
      } else {
        await createProduct(activeBusiness.id, actor, {
          name,
          sku,
          category,
          brand,
          unit,
          purchasePrice: pp,
          sellingPrice: sp,
          gstRate,
          currentStock: st,
          lowStockThreshold: low,
          supplierName,
          supplierPhone,
        });
      }
      setProductModalOpen(false);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to save product.');
    } finally {
      setSaving(false);
    }
  };

  const handleAdjustStock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBusiness || !actor || !adjustTarget) return;
    setAdjustError(null);

    const qty = Number(adjustQty);
    if (!Number.isInteger(qty) || qty <= 0) {
      return setAdjustError('Please enter a valid whole number greater than 0.');
    }
    if (adjustType === 'adjustment_out' && qty > adjustTarget.currentStock) {
      return setAdjustError(`Cannot deduct ${qty}. Only ${adjustTarget.currentStock} ${adjustTarget.unit} in stock.`);
    }
    if (!adjustReason.trim()) {
      return setAdjustError('Please enter a brief reason (e.g. Supplier restock, Damaged item).');
    }

    setAdjusting(true);
    try {
      await adjustProductStock(activeBusiness.id, adjustTarget.id, actor, {
        type: adjustType,
        quantity: qty,
        reason: adjustReason,
      });
      setAdjustTarget(null);
      setAdjustQty('');
      setAdjustReason('');
    } catch (err) {
      setAdjustError(err instanceof Error ? err.message : 'Failed to adjust stock.');
    } finally {
      setAdjusting(false);
    }
  };

  const handleDeleteProduct = async () => {
    if (!activeBusiness || !actor || !deleteTarget) return;
    setDeleting(true);
    try {
      await deleteProduct(activeBusiness.id, deleteTarget, actor);
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return <TableSkeleton rows={6} />;
  }

  return (
    <div className="space-y-5">
      {/* Top KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <StatCard label="Total SKUs" value={formatCount(products.length)} subtext="Active catalog items" />
        <StatCard label="Total Stock Units" value={formatCount(summary.totalUnits)} subtext="Across all products" />
        <StatCard
          label="Inventory Cost Value"
          value={formatINR(summary.stockCostValue)}
          subtext="At purchase price"
          tone="emerald"
        />
        <StatCard
          label="Low-Stock Alerts"
          value={formatCount(summary.lowCount)}
          subtext="Items needing reorder"
          tone={summary.lowCount > 0 ? 'rose' : 'emerald'}
        />
      </div>

      {/* Controls Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="inline-flex items-center p-1 bg-slate-200/70 rounded-lg self-start">
          <button
            type="button"
            onClick={() => setView('catalog')}
            className={`min-h-[36px] px-3.5 py-1.5 text-xs font-medium rounded-md inline-flex items-center gap-1.5 cursor-pointer ${
              view === 'catalog' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Products ({products.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setView('history')}
            className={`min-h-[36px] px-3.5 py-1.5 text-xs font-medium rounded-md inline-flex items-center gap-1.5 cursor-pointer ${
              view === 'history' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Stock Movements ({stockMovements.length})</span>
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, SKU, supplier..."
              className="w-full min-h-[40px] pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
            />
          </div>

          {view === 'catalog' && (
            <>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                aria-label="Filter by category"
                className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs sm:text-sm text-slate-700"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat === 'all' ? 'All Categories' : cat}
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={() => setLowStockOnly((v) => !v)}
                className={`min-h-[40px] px-3 py-1.5 rounded-lg border text-xs sm:text-sm font-medium inline-flex items-center gap-1.5 cursor-pointer ${
                  lowStockOnly
                    ? 'border-amber-300 bg-amber-50 text-amber-800'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Low Stock</span>
              </button>

              {permissions.canManageInventory && (
                <button
                  type="button"
                  onClick={openAddModal}
                  className="min-h-[40px] px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-medium inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Product</span>
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Catalog View */}
      {view === 'catalog' ? (
        filteredProducts.length === 0 ? (
          <EmptyState
            icon={Package}
            title={products.length === 0 ? 'No products in inventory' : 'No matching products'}
            description={
              products.length === 0
                ? 'Add your first product with SKU, purchase price, selling price, and opening stock.'
                : 'Try clearing your search or category filters.'
            }
            actionLabel={permissions.canManageInventory && products.length === 0 ? 'Add First Product' : undefined}
            onAction={permissions.canManageInventory && products.length === 0 ? openAddModal : undefined}
          />
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden md:block bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500">
                      <th className="py-3 px-4">Product & SKU</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4 text-right">Purchase</th>
                      <th className="py-3 px-4 text-right">Selling (GST)</th>
                      <th className="py-3 px-4 text-right">Stock</th>
                      <th className="py-3 px-4">Supplier</th>
                      {permissions.canManageInventory && <th className="py-3 px-4 text-right">Actions</th>}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {filteredProducts.map((p) => {
                      const isLow = p.currentStock <= p.lowStockThreshold;
                      return (
                        <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="py-3 px-4">
                            <div className="font-medium text-slate-900">{p.name}</div>
                            <div className="text-xs font-mono text-slate-500">
                              {p.sku}
                              {p.brand ? ` · ${p.brand}` : ''}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-xs text-slate-600">{p.category}</td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                            {formatINR(p.purchasePrice)}
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums">
                            <div className="font-semibold text-slate-900">{formatINR(p.sellingPrice)}</div>
                            <div className="text-[11px] text-slate-400">GST {p.gstRate}%</div>
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums">
                            <div
                              className={`font-semibold ${
                                p.currentStock === 0
                                  ? 'text-rose-600'
                                  : isLow
                                    ? 'text-amber-700'
                                    : 'text-emerald-700'
                              }`}
                            >
                              {p.currentStock} {p.unit}
                            </div>
                            <div className="text-[11px] text-slate-400">Min {p.lowStockThreshold}</div>
                          </td>
                          <td className="py-3 px-4 text-xs text-slate-600">
                            <div>{p.supplierName || '—'}</div>
                            {p.supplierPhone && <div className="text-slate-400">{p.supplierPhone}</div>}
                          </td>
                          {permissions.canManageInventory && (
                            <td className="py-3 px-4 text-right">
                              <div className="inline-flex items-center justify-end gap-1">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setAdjustTarget(p);
                                    setAdjustType('purchase');
                                    setAdjustQty('');
                                    setAdjustReason('');
                                    setAdjustError(null);
                                  }}
                                  title="Adjust stock"
                                  className="min-h-[34px] px-2.5 py-1 rounded-md border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-100 inline-flex items-center gap-1 cursor-pointer"
                                >
                                  <ArrowUpDown className="w-3.5 h-3.5" />
                                  <span>Stock</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openEditModal(p)}
                                  title="Edit product"
                                  className="min-w-[34px] min-h-[34px] rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 inline-flex items-center justify-center cursor-pointer"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>
                                {permissions.canViewFinance && (
                                  <button
                                    type="button"
                                    onClick={() => setDeleteTarget(p)}
                                    title="Delete product"
                                    className="min-w-[34px] min-h-[34px] rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 inline-flex items-center justify-center cursor-pointer"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                )}
                              </div>
                            </td>
                          )}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Mobile Card List */}
            <div className="md:hidden space-y-3">
              {filteredProducts.map((p) => {
                const isLow = p.currentStock <= p.lowStockThreshold;
                return (
                  <div key={p.id} className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-slate-900">{p.name}</div>
                        <div className="text-xs text-slate-500 font-mono">
                          {p.sku} · {p.category}
                        </div>
                      </div>
                      <div
                        className={`text-sm font-mono font-bold tabular-nums shrink-0 ${
                          p.currentStock === 0 ? 'text-rose-600' : isLow ? 'text-amber-700' : 'text-emerald-700'
                        }`}
                      >
                        {p.currentStock} {p.unit}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-600 pt-2 border-t border-slate-100">
                      <span>
                        Buy <strong className="font-mono">{formatINR(p.purchasePrice)}</strong> · Sell{' '}
                        <strong className="font-mono text-slate-900">{formatINR(p.sellingPrice)}</strong>
                      </span>
                      <span>GST {p.gstRate}%</span>
                    </div>

                    {permissions.canManageInventory && (
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            setAdjustTarget(p);
                            setAdjustType('purchase');
                            setAdjustQty('');
                            setAdjustReason('');
                            setAdjustError(null);
                          }}
                          className="flex-1 min-h-[40px] rounded-lg border border-slate-200 text-xs font-medium text-slate-700 inline-flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <ArrowUpDown className="w-3.5 h-3.5" />
                          <span>Adjust Stock</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => openEditModal(p)}
                          className="min-h-[40px] px-3.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                        {permissions.canViewFinance && (
                          <button
                            type="button"
                            onClick={() => setDeleteTarget(p)}
                            aria-label={`Delete ${p.name}`}
                            className="min-h-[40px] min-w-[40px] rounded-lg border border-rose-200 text-rose-600 flex items-center justify-center cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </>
        )
      ) : filteredMovements.length === 0 ? (
        <EmptyState
          icon={History}
          title="No stock movement history"
          description="Every opening stock, purchase restock, sale deduction, return, and manual adjustment is logged here."
        />
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500">
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Product</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4 text-right">Change</th>
                  <th className="py-3 px-4 text-right">Balance</th>
                  <th className="py-3 px-4">Reference / Reason</th>
                  <th className="py-3 px-4">Staff</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
                {filteredMovements.map((m) => (
                  <tr key={m.id} className="hover:bg-slate-50/60">
                    <td className="py-3 px-4 text-xs text-slate-500 whitespace-nowrap font-mono">
                      {formatDateTimeIN(m.createdAt)}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900">{m.productName}</div>
                      <div className="text-xs font-mono text-slate-400">{m.sku}</div>
                    </td>
                    <td className="py-3 px-4 text-xs capitalize text-slate-700">
                      {m.type.replace('_', ' ')}
                    </td>
                    <td
                      className={`py-3 px-4 text-right font-mono font-semibold tabular-nums ${
                        m.quantityDelta >= 0 ? 'text-emerald-700' : 'text-rose-600'
                      }`}
                    >
                      {m.quantityDelta > 0 ? `+${m.quantityDelta}` : m.quantityDelta}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                      {m.previousStock} → <strong>{m.newStock}</strong>
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-600">
                      {m.referenceId ? <span className="font-mono text-slate-800 mr-1.5">{m.referenceId}</span> : null}
                      {m.reason || '—'}
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-500">{m.performedByName}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit Product Modal */}
      <Modal
        open={productModalOpen}
        onClose={() => setProductModalOpen(false)}
        title={editingProduct ? 'Edit Product Details' : 'Add New Product'}
        subtitle="Configure pricing, GST rate, alert threshold, and supplier"
        maxWidthClass="sm:max-w-xl"
      >
        <form onSubmit={handleSaveProduct} className="space-y-4">
          <FormErrorBanner message={formError} />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">Product Name *</label>
              <input
                type="text"
                required
                maxLength={FIELD_LIMITS.productName.max}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Samsung 25W PD Type-C Adapter"
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">SKU Code *</label>
              <input
                type="text"
                required
                maxLength={FIELD_LIMITS.sku.max}
                value={sku}
                onChange={(e) => setSku(e.target.value.toUpperCase())}
                placeholder="CHG-SAM-25W"
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono uppercase"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Category *</label>
              <input
                type="text"
                list="bizora-categories"
                required
                maxLength={FIELD_LIMITS.category.max}
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
              <datalist id="bizora-categories">
                {DEFAULT_CATEGORIES.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Brand</label>
              <input
                type="text"
                maxLength={FIELD_LIMITS.brand.max}
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                placeholder="Samsung"
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Unit *</label>
              <select
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white"
              >
                <option value="pcs">pcs</option>
                <option value="box">box</option>
                <option value="pack">pack</option>
                <option value="set">set</option>
                <option value="kg">kg</option>
                <option value="mtr">mtr</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Purchase Price (₹) *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Selling Price (₹) *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                value={sellingPrice}
                onChange={(e) => setSellingPrice(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">GST Rate (%)</label>
              <select
                value={gstRate}
                onChange={(e) => setGstRate(Number(e.target.value) as 0 | 5 | 12 | 18 | 28)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white font-mono"
              >
                <option value={0}>0% (Exempt)</option>
                <option value={5}>5% GST</option>
                <option value={12}>12% GST</option>
                <option value={18}>18% GST</option>
                <option value={28}>28% GST</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Low-Stock Alert Threshold *</label>
              <input
                type="number"
                min="0"
                step="1"
                required
                value={lowStockThreshold}
                onChange={(e) => setLowStockThreshold(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono"
              />
            </div>

            {!editingProduct && (
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-700 mb-1">Opening Stock Quantity *</label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  required
                  value={currentStock}
                  onChange={(e) => setCurrentStock(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Supplier Name</label>
              <input
                type="text"
                maxLength={FIELD_LIMITS.supplierName.max}
                value={supplierName}
                onChange={(e) => setSupplierName(e.target.value)}
                placeholder="Wholesale distributor"
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Supplier Phone</label>
              <input
                type="tel"
                maxLength={FIELD_LIMITS.phone.max}
                value={supplierPhone}
                onChange={(e) => setSupplierPhone(e.target.value)}
                placeholder="+91 98..."
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={() => setProductModalOpen(false)}
              className="min-h-[42px] px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium text-slate-700 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="min-h-[42px] px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
            >
              {saving ? 'Saving...' : editingProduct ? 'Save Changes' : 'Add Product'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Stock Adjustment Modal */}
      <Modal
        open={Boolean(adjustTarget)}
        onClose={() => setAdjustTarget(null)}
        title={`Adjust Stock · ${adjustTarget?.name || ''}`}
        subtitle={`Current stock: ${adjustTarget?.currentStock || 0} ${adjustTarget?.unit || ''}`}
      >
        <form onSubmit={handleAdjustStock} className="space-y-4">
          <FormErrorBanner message={adjustError} />

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Adjustment Type</label>
            <select
              value={adjustType}
              onChange={(e) => setAdjustType(e.target.value as 'purchase' | 'adjustment_in' | 'adjustment_out')}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white"
            >
              <option value="purchase">Purchase / Supplier Restock (+)</option>
              <option value="adjustment_in">Manual Stock Increase (+)</option>
              <option value="adjustment_out">Manual Stock Deduction / Damage (-)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Quantity *</label>
            <input
              type="number"
              min="1"
              step="1"
              required
              value={adjustQty}
              onChange={(e) => setAdjustQty(e.target.value)}
              placeholder="Enter units"
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Reason / Invoice Reference *</label>
            <input
              type="text"
              required
              maxLength={FIELD_LIMITS.reason.max}
              value={adjustReason}
              onChange={(e) => setAdjustReason(e.target.value)}
              placeholder="e.g. Restock from Balaji Distributors Bill #881"
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          <div className="flex justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={() => setAdjustTarget(null)}
              className="min-h-[42px] px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium text-slate-700 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={adjusting}
              className="min-h-[42px] px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
            >
              {adjusting ? 'Updating...' : 'Apply Adjustment'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="Delete Product"
        description={`Are you sure you want to remove "${deleteTarget?.name}" (${deleteTarget?.sku})? Existing invoices and past stock movement history will remain preserved.`}
        confirmLabel="Delete Product"
        loading={deleting}
        onConfirm={handleDeleteProduct}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
