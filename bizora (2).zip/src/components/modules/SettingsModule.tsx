import React, { useEffect, useState } from 'react';
import { Check, Save, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { FIELD_LIMITS, isValidGstin, isValidPhone } from '../../lib/validation';
import { updateBusinessSettings } from '../../services/bizoraService';
import { FormErrorBanner } from '../ui/DataPrimitives';

export function SettingsModule() {
  const { activeBusiness, actor } = useAuth();

  const [name, setName] = useState('');
  const [tagline, setTagline] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [stateName, setStateName] = useState('');
  const [pincode, setPincode] = useState('');
  const [invoicePrefix, setInvoicePrefix] = useState('INV');
  const [gstEnabled, setGstEnabled] = useState(true);
  const [gstin, setGstin] = useState('');

  const [error, setError] = useState<string | null>(null);
  const [savedNotice, setSavedNotice] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!activeBusiness) return;
    setName(activeBusiness.name || '');
    setTagline(activeBusiness.tagline || '');
    setPhone(activeBusiness.phone || '');
    setEmail(activeBusiness.email || '');
    setAddress(activeBusiness.address || '');
    setCity(activeBusiness.city || '');
    setStateName(activeBusiness.state || '');
    setPincode(activeBusiness.pincode || '');
    setInvoicePrefix(activeBusiness.invoicePrefix || 'INV');
    setGstEnabled(Boolean(activeBusiness.gstEnabled));
    setGstin(activeBusiness.gstin || '');
  }, [activeBusiness]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBusiness || !actor) return;
    setError(null);
    setSavedNotice(false);

    if (name.trim().length < FIELD_LIMITS.businessName.min) {
      return setError('Business name must be at least 2 characters.');
    }
    if (phone.trim() && !isValidPhone(phone)) {
      return setError('Enter a valid phone number (6–20 digits).');
    }
    if (gstin.trim() && !isValidGstin(gstin)) {
      return setError('Invalid GSTIN format. Must be 15 alphanumeric characters (e.g. 29AABCU9603R1ZM).');
    }

    setSaving(true);
    try {
      await updateBusinessSettings(activeBusiness.id, actor, {
        name,
        tagline,
        phone,
        email,
        address,
        city,
        state: stateName,
        pincode,
        invoicePrefix,
        gstEnabled,
        gstin,
      });
      setSavedNotice(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update settings.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-3xl space-y-6">
      <form onSubmit={handleSave} className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-5">
        <div className="border-b border-slate-100 pb-4">
          <h2 className="text-base font-semibold text-slate-900">Business Profile & Invoice Configuration</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Printed on customer invoices and used across your Indian GST billing calculations.
          </p>
        </div>

        <FormErrorBanner message={error} />

        {savedNotice && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3.5 py-2.5 text-xs sm:text-sm text-emerald-800 flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" />
            <span>Business settings saved successfully.</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-slate-700 mb-1">Business Name *</label>
            <input
              type="text"
              required
              maxLength={FIELD_LIMITS.businessName.max}
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-slate-700 mb-1">Tagline</label>
            <input
              type="text"
              maxLength={FIELD_LIMITS.tagline.max}
              value={tagline}
              onChange={(e) => setTagline(e.target.value)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Phone</label>
            <input
              type="tel"
              maxLength={FIELD_LIMITS.phone.max}
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Business Email</label>
            <input
              type="email"
              maxLength={FIELD_LIMITS.email.max}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-slate-700 mb-1">Street Address</label>
            <input
              type="text"
              maxLength={FIELD_LIMITS.address.max}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">City</label>
            <input
              type="text"
              maxLength={FIELD_LIMITS.city.max}
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">State</label>
            <input
              type="text"
              maxLength={FIELD_LIMITS.state.max}
              value={stateName}
              onChange={(e) => setStateName(e.target.value)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">PIN Code</label>
            <input
              type="text"
              maxLength={FIELD_LIMITS.pincode.max}
              value={pincode}
              onChange={(e) => setPincode(e.target.value)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Invoice Prefix *</label>
            <input
              type="text"
              required
              maxLength={FIELD_LIMITS.invoicePrefix.max}
              value={invoicePrefix}
              onChange={(e) => setInvoicePrefix(e.target.value.toUpperCase())}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono uppercase"
            />
          </div>

          <div className="sm:col-span-2 pt-2 border-t border-slate-100 space-y-3">
            <label className="inline-flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={gstEnabled}
                onChange={(e) => setGstEnabled(e.target.checked)}
                className="w-4 h-4 accent-emerald-600 rounded"
              />
              <span className="text-sm font-medium text-slate-800">Enable GST tax calculation by default on new bills</span>
            </label>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">15-Digit GSTIN</label>
              <input
                type="text"
                maxLength={15}
                value={gstin}
                onChange={(e) => setGstin(e.target.value.toUpperCase())}
                placeholder="29AABCU9603R1ZM"
                className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono uppercase"
              />
              <div className="mt-2 flex items-start gap-2 text-xs text-slate-500">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  BIZORA validates GSTIN structure locally and computes CGST/SGST or IGST totals from item rates. It does not file GSTR returns directly with GSTN; please verify statutory compliance with a qualified tax advisor.
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={saving}
            className="min-h-[44px] px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold inline-flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving...' : 'Save Settings'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
