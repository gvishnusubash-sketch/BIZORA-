import React, { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  FileText,
  Minus,
  Plus,
  Printer,
  ReceiptIndianRupee,
  RotateCcw,
  Search,
  ShoppingCart,
  Trash2,
  UserPlus,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useBusinessData } from '../../contexts/BusinessDataContext';
import { formatDateIN, formatDateTimeIN, formatINR } from '../../lib/formatters';
import { FIELD_LIMITS, isValidGstin, isValidPhone, roundInr } from '../../lib/validation';
import {
  createCustomer,
  createSaleInvoice,
  processSaleReturnOrCancel,
  recordCustomerPayment,
} from '../../services/bizoraService';
import type { GstMode, NonCreditPaymentMethod, PaymentMethod, Product, Sale } from '../../types/bizora';
import { EmptyState, FormErrorBanner, TableSkeleton } from '../ui/DataPrimitives';
import { Modal } from '../ui/Modal';

interface CartLine {
  product: Product;
  quantity: number;
  unitPrice: number;
  discountAmount: number;
}

interface SalesBillingModuleProps {
  openNewBillSignal: number;
}

export function SalesBillingModule({ openNewBillSignal }: SalesBillingModuleProps) {
  const { activeBusiness, actor } = useAuth();
  const { products, customers, sales, loading } = useBusinessData();

  const [tab, setTab] = useState<'pos' | 'history'>('pos');
  const [productSearch, setProductSearch] = useState('');
  const [cart, setCart] = useState<CartLine[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('walk-in');
  const [gstMode, setGstMode] = useState<GstMode>(activeBusiness?.gstEnabled ? 'cgst_sgst' : 'none');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('upi');
  const [customAmountPaid, setCustomAmountPaid] = useState<string>('');
  const [posError, setPosError] = useState<string | null>(null);
  const [submittingSale, setSubmittingSale] = useState(false);

  // Quick Add Customer Modal inside POS
  const [quickCustOpen, setQuickCustOpen] = useState(false);
  const [qcName, setQcName] = useState('');
  const [qcPhone, setQcPhone] = useState('');
  const [qcError, setQcError] = useState<string | null>(null);
  const [qcSaving, setQcSaving] = useState(false);

  // History Filters
  const [historySearch, setHistorySearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'due' | 'returned'>('all');

  // Invoice Print Modal
  const [previewSale, setPreviewSale] = useState<Sale | null>(null);

  // Return / Cancel Modal
  const [returnTarget, setReturnTarget] = useState<Sale | null>(null);
  const [returnType, setReturnType] = useState<'returned' | 'cancelled'>('returned');
  const [returnReason, setReturnReason] = useState('');
  const [returnError, setReturnError] = useState<string | null>(null);
  const [returning, setReturning] = useState(false);

  // Collect Due Modal
  const [collectTarget, setCollectTarget] = useState<Sale | null>(null);
  const [collectAmount, setCollectAmount] = useState('');
  const [collectMethod, setCollectMethod] = useState<NonCreditPaymentMethod>('upi');
  const [collectNote, setCollectNote] = useState('');
  const [collectError, setCollectError] = useState<string | null>(null);
  const [collecting, setCollecting] = useState(false);

  useEffect(() => {
    if (openNewBillSignal > 0) {
      setTab('pos');
    }
  }, [openNewBillSignal]);

  useEffect(() => {
    setGstMode(activeBusiness?.gstEnabled ? 'cgst_sgst' : 'none');
  }, [activeBusiness?.gstEnabled]);

  const filteredPosProducts = useMemo(() => {
    const q = productSearch.trim().toLowerCase();
    return products
      .filter((p) => {
        if (!q) return true;
        return (
          p.name.toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q)
        );
      })
      .slice(0, 24);
  }, [products, productSearch]);

  const cartTotals = useMemo(() => {
    let subtotal = 0;
    let discountTotal = 0;
    let taxTotal = 0;

    for (const line of cart) {
      const gross = roundInr(line.unitPrice * line.quantity);
      const disc = roundInr(Math.min(gross, Math.max(0, line.discountAmount)));
      const taxable = roundInr(gross - disc);
      const rate = gstMode === 'none' ? 0 : line.product.gstRate;
      const tax = roundInr((taxable * rate) / 100);
      subtotal = roundInr(subtotal + gross);
      discountTotal = roundInr(discountTotal + disc);
      taxTotal = roundInr(taxTotal + tax);
    }
    const grandTotal = roundInr(subtotal - discountTotal + taxTotal);
    const effectivePaid =
      paymentMethod === 'credit'
        ? roundInr(Math.min(grandTotal, Math.max(0, Number(customAmountPaid || 0))))
        : customAmountPaid !== ''
          ? roundInr(Math.min(grandTotal, Math.max(0, Number(customAmountPaid))))
          : grandTotal;
    const balanceDue = roundInr(Math.max(0, grandTotal - effectivePaid));
    return { subtotal, discountTotal, taxTotal, grandTotal, effectivePaid, balanceDue };
  }, [cart, gstMode, paymentMethod, customAmountPaid]);

  const addToCart = (product: Product) => {
    setPosError(null);
    if (product.currentStock <= 0) {
      setPosError(`${product.name} is currently out of stock.`);
      return;
    }
    setCart((prev) => {
      const idx = prev.findIndex((l) => l.product.id === product.id);
      if (idx >= 0) {
        const existing = prev[idx];
        if (existing.quantity + 1 > product.currentStock) {
          setPosError(`Only ${product.currentStock} ${product.unit} available for ${product.name}.`);
          return prev;
        }
        return prev.map((l, i) => (i === idx ? { ...l, quantity: l.quantity + 1 } : l));
      }
      if (prev.length >= FIELD_LIMITS.maxSaleItems) {
        setPosError(`Maximum ${FIELD_LIMITS.maxSaleItems} line items allowed per bill.`);
        return prev;
      }
      return [...prev, { product, quantity: 1, unitPrice: product.sellingPrice, discountAmount: 0 }];
    });
  };

  const updateCartQty = (productId: string, nextQty: number) => {
    setPosError(null);
    setCart((prev) =>
      prev
        .map((line) => {
          if (line.product.id !== productId) return line;
          if (nextQty <= 0) return null;
          if (nextQty > line.product.currentStock) {
            setPosError(`Max available stock for ${line.product.name} is ${line.product.currentStock}.`);
            return { ...line, quantity: line.product.currentStock };
          }
          return { ...line, quantity: Math.floor(nextQty) };
        })
        .filter((x): x is CartLine => x !== null)
    );
  };

  const updateCartLinePriceOrDiscount = (
    productId: string,
    field: 'unitPrice' | 'discountAmount',
    val: number
  ) => {
    setCart((prev) =>
      prev.map((line) =>
        line.product.id === productId ? { ...line, [field]: Math.max(0, val) } : line
      )
    );
  };

  const handleQuickAddCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBusiness || !actor) return;
    setQcError(null);
    if (qcName.trim().length < 2) return setQcError('Customer name must be at least 2 characters.');
    if (!isValidPhone(qcPhone)) return setQcError('Enter a valid 6–20 digit phone number.');

    setQcSaving(true);
    try {
      const id = await createCustomer(activeBusiness.id, actor, {
        name: qcName.trim(),
        phone: qcPhone.trim(),
      });
      setSelectedCustomerId(id);
      setQcName('');
      setQcPhone('');
      setQuickCustOpen(false);
    } catch (err) {
      setQcError(err instanceof Error ? err.message : 'Failed to create customer.');
    } finally {
      setQcSaving(false);
    }
  };

  const handleCompleteSale = async () => {
    if (!activeBusiness || !actor) return;
    setPosError(null);

    if (cart.length === 0) {
      return setPosError('Add at least one product to the bill before generating an invoice.');
    }
    if (cartTotals.balanceDue > 0 && selectedCustomerId === 'walk-in') {
      return setPosError('Select or add a customer when creating a credit or partial-payment bill.');
    }

    const chosenCustomer = customers.find((c) => c.id === selectedCustomerId);
    setSubmittingSale(true);
    try {
      const created = await createSaleInvoice(activeBusiness.id, actor, {
        customerId: chosenCustomer?.id,
        customerName: chosenCustomer?.name || 'Walk-in Customer',
        customerPhone: chosenCustomer?.phone,
        items: cart.map((l) => ({
          productId: l.product.id,
          quantity: l.quantity,
          unitPrice: l.unitPrice,
          discountAmount: l.discountAmount,
          gstRate: l.product.gstRate,
        })),
        gstMode,
        paymentMethod,
        amountPaid: cartTotals.effectivePaid,
      });

      setCart([]);
      setCustomAmountPaid('');
      setSelectedCustomerId('walk-in');
      setPreviewSale(created);
    } catch (err) {
      setPosError(err instanceof Error ? err.message : 'Could not complete sale.');
    } finally {
      setSubmittingSale(false);
    }
  };

  const filteredSales = useMemo(() => {
    const q = historySearch.trim().toLowerCase();
    return sales.filter((s) => {
      if (statusFilter === 'completed' && s.status !== 'completed') return false;
      if (statusFilter === 'due' && (s.status !== 'completed' || s.balanceDue <= 0)) return false;
      if (statusFilter === 'returned' && s.status === 'completed') return false;
      if (!q) return true;
      return (
        s.invoiceNumber.toLowerCase().includes(q) ||
        s.customerName.toLowerCase().includes(q) ||
        (s.customerPhone || '').toLowerCase().includes(q)
      );
    });
  }, [sales, historySearch, statusFilter]);

  const handleProcessReturn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBusiness || !actor || !returnTarget) return;
    setReturnError(null);
    if (!returnReason.trim()) {
      return setReturnError('Please specify a reason for this return or cancellation.');
    }

    setReturning(true);
    try {
      await processSaleReturnOrCancel(activeBusiness.id, returnTarget.id, actor, {
        targetStatus: returnType,
        reason: returnReason.trim(),
      });
      setReturnTarget(null);
      setReturnReason('');
    } catch (err) {
      setReturnError(err instanceof Error ? err.message : 'Failed to process return.');
    } finally {
      setReturning(false);
    }
  };

  const handleCollectDue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBusiness || !actor || !collectTarget || !collectTarget.customerId) return;
    setCollectError(null);
    const amt = Number(collectAmount);
    if (!Number.isFinite(amt) || amt <= 0) {
      return setCollectError('Enter a valid amount greater than ₹0.');
    }
    if (amt > collectTarget.balanceDue + 0.01) {
      return setCollectError(`Amount cannot exceed invoice balance of ${formatINR(collectTarget.balanceDue, true)}.`);
    }

    setCollecting(true);
    try {
      await recordCustomerPayment(activeBusiness.id, actor, {
        customerId: collectTarget.customerId,
        saleId: collectTarget.id,
        amount: amt,
        method: collectMethod,
        referenceNote: collectNote.trim() || `Payment against ${collectTarget.invoiceNumber}`,
      });
      setCollectTarget(null);
      setCollectAmount('');
      setCollectNote('');
    } catch (err) {
      setCollectError(err instanceof Error ? err.message : 'Could not record payment.');
    } finally {
      setCollecting(false);
    }
  };

  const businessHasValidGstin = Boolean(activeBusiness?.gstin && isValidGstin(activeBusiness.gstin));

  if (loading) {
    return <TableSkeleton rows={6} />;
  }

  return (
    <div className="space-y-5">
      {/* Mode Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex items-center p-1 bg-slate-200/70 rounded-lg">
          <button
            type="button"
            onClick={() => setTab('pos')}
            className={`min-h-[36px] px-4 py-1.5 text-xs font-medium rounded-md inline-flex items-center gap-1.5 cursor-pointer ${
              tab === 'pos' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>Create Bill</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('history')}
            className={`min-h-[36px] px-4 py-1.5 text-xs font-medium rounded-md inline-flex items-center gap-1.5 cursor-pointer ${
              tab === 'history' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Sales History ({sales.length})</span>
          </button>
        </div>

        <div className="text-xs text-slate-500">
          Next Invoice: <span className="font-mono font-semibold text-slate-900">{activeBusiness?.invoicePrefix}-{activeBusiness?.nextInvoiceNumber}</span>
        </div>
      </div>

      {tab === 'pos' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Product Picker */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-4 sm:p-5 space-y-4">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={productSearch}
                onChange={(e) => setProductSearch(e.target.value)}
                placeholder="Search products by name, SKU, or category to add..."
                className="w-full min-h-[42px] pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
              />
            </div>

            {products.length === 0 ? (
              <EmptyState
                icon={ShoppingCart}
                title="No products available to bill"
                description="Add products in the Inventory module first before creating a sales invoice."
              />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[520px] overflow-y-auto pr-0.5">
                {filteredPosProducts.map((p) => {
                  const out = p.currentStock <= 0;
                  const inCartQty = cart.find((c) => c.product.id === p.id)?.quantity || 0;
                  return (
                    <button
                      key={p.id}
                      type="button"
                      disabled={out}
                      onClick={() => addToCart(p)}
                      className={`text-left p-3 rounded-xl border transition-colors flex flex-col justify-between gap-2 min-h-[84px] ${
                        out
                          ? 'border-slate-100 bg-slate-50 opacity-60 cursor-not-allowed'
                          : inCartQty > 0
                            ? 'border-emerald-500 bg-emerald-50/40 hover:bg-emerald-50 cursor-pointer'
                            : 'border-slate-200 hover:border-emerald-500 hover:bg-slate-50 cursor-pointer'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-slate-900 line-clamp-1">{p.name}</div>
                          <div className="text-[11px] font-mono text-slate-500">{p.sku}</div>
                        </div>
                        {inCartQty > 0 && (
                          <span className="text-xs font-mono font-bold text-emerald-700 shrink-0">
                            ×{inCartQty}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between text-xs pt-1">
                        <span className="font-mono font-bold text-slate-900">
                          {formatINR(p.sellingPrice)}
                          <span className="font-normal text-slate-400"> · {p.gstRate}% GST</span>
                        </span>
                        <span
                          className={`font-mono ${
                            out ? 'text-rose-600' : p.currentStock <= p.lowStockThreshold ? 'text-amber-700' : 'text-slate-500'
                          }`}
                        >
                          {out ? 'Out of stock' : `${p.currentStock} ${p.unit}`}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Bill / Cart Summary */}
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-4 sm:p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-semibold text-slate-900">Current Bill</h3>
              {cart.length > 0 && (
                <button
                  type="button"
                  onClick={() => setCart([])}
                  className="text-xs text-rose-600 hover:underline cursor-pointer"
                >
                  Clear Cart
                </button>
              )}
            </div>

            <FormErrorBanner message={posError} />

            {/* Customer Selector */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-slate-700">Customer</label>
                <button
                  type="button"
                  onClick={() => {
                    setQcError(null);
                    setQuickCustOpen(true);
                  }}
                  className="text-xs font-medium text-emerald-700 hover:underline inline-flex items-center gap-1 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Quick Add</span>
                </button>
              </div>
              <select
                value={selectedCustomerId}
                onChange={(e) => setSelectedCustomerId(e.target.value)}
                className="w-full min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-200 text-sm bg-white"
              >
                <option value="walk-in">Walk-in Customer</option>
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.phone})
                  </option>
                ))}
              </select>
            </div>

            {/* Cart Items */}
            {cart.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-xl">
                Select products from the left to build an invoice.
              </div>
            ) : (
              <div className="divide-y divide-slate-100 max-h-64 overflow-y-auto pr-1">
                {cart.map((line) => {
                  const gross = line.unitPrice * line.quantity;
                  const net = Math.max(0, gross - line.discountAmount);
                  const tax = gstMode === 'none' ? 0 : (net * line.product.gstRate) / 100;
                  return (
                    <div key={line.product.id} className="py-2.5 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-xs font-semibold text-slate-900 truncate">
                            {line.product.name}
                          </div>
                          <div className="text-[11px] font-mono text-slate-400">
                            {formatINR(line.unitPrice)} × {line.quantity}
                            {gstMode !== 'none' ? ` + ${line.product.gstRate}% GST` : ''}
                          </div>
                        </div>
                        <div className="text-xs font-mono font-semibold text-slate-900 shrink-0">
                          {formatINR(net + tax, true)}
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <div className="inline-flex items-center border border-slate-200 rounded-lg">
                          <button
                            type="button"
                            onClick={() => updateCartQty(line.product.id, line.quantity - 1)}
                            className="w-8 h-8 flex items-center justify-center text-slate-600 hover:bg-slate-100 cursor-pointer"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <input
                            type="number"
                            min="1"
                            max={line.product.currentStock}
                            value={line.quantity}
                            onChange={(e) => updateCartQty(line.product.id, Number(e.target.value))}
                            className="w-10 text-center text-xs font-mono focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => updateCartQty(line.product.id, line.quantity + 1)}
                            className="w-8 h-8 flex items-center justify-center text-slate-600 hover:bg-slate-100 cursor-pointer"
                            aria-label="Increase quantity"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <label className="text-[11px] text-slate-500">Disc ₹</label>
                          <input
                            type="number"
                            min="0"
                            step="1"
                            value={line.discountAmount || ''}
                            placeholder="0"
                            onChange={(e) =>
                              updateCartLinePriceOrDiscount(
                                line.product.id,
                                'discountAmount',
                                Number(e.target.value || 0)
                              )
                            }
                            className="w-16 h-8 px-2 rounded-lg border border-slate-200 text-xs font-mono text-right"
                          />
                          <button
                            type="button"
                            onClick={() => updateCartQty(line.product.id, 0)}
                            aria-label="Remove item"
                            className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-rose-600 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Tax & Payment Controls */}
            <div className="space-y-3 pt-2 border-t border-slate-100">
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-1">GST Mode</label>
                  <select
                    value={gstMode}
                    onChange={(e) => setGstMode(e.target.value as GstMode)}
                    className="w-full min-h-[38px] px-2.5 py-1 rounded-lg border border-slate-200 text-xs bg-white"
                  >
                    <option value="cgst_sgst">CGST + SGST (Intra-State)</option>
                    <option value="igst">IGST (Inter-State)</option>
                    <option value="none">No Tax / Composition</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-1">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => {
                      const val = e.target.value as PaymentMethod;
                      setPaymentMethod(val);
                      if (val === 'credit') setCustomAmountPaid('0');
                      else setCustomAmountPaid('');
                    }}
                    className="w-full min-h-[38px] px-2.5 py-1 rounded-lg border border-slate-200 text-xs bg-white"
                  >
                    <option value="upi">UPI (GPay / PhonePe)</option>
                    <option value="cash">Cash</option>
                    <option value="card">Card</option>
                    <option value="bank_transfer">Bank Transfer (NEFT/IMPS)</option>
                    <option value="credit">Credit / Khata</option>
                  </select>
                </div>
              </div>

              {gstMode !== 'none' && !businessHasValidGstin && (
                <p className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5">
                  GST estimate mode: add a valid 15-character GSTIN in Business Settings before issuing formal GST tax invoices.
                </p>
              )}

              <div>
                <label className="block text-[11px] font-medium text-slate-600 mb-1">
                  Amount Received Now (₹) — leave blank for full payment
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  max={cartTotals.grandTotal}
                  value={customAmountPaid}
                  onChange={(e) => setCustomAmountPaid(e.target.value)}
                  placeholder={String(cartTotals.grandTotal)}
                  className="w-full min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-200 text-sm font-mono"
                />
              </div>

              {/* Totals Summary */}
              <div className="bg-slate-50 rounded-xl p-3.5 space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal</span>
                  <span className="font-mono tabular-nums">{formatINR(cartTotals.subtotal, true)}</span>
                </div>
                {cartTotals.discountTotal > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount</span>
                    <span className="font-mono tabular-nums">-{formatINR(cartTotals.discountTotal, true)}</span>
                  </div>
                )}
                {gstMode !== 'none' && (
                  <div className="flex justify-between text-slate-600">
                    <span>{gstMode === 'cgst_sgst' ? 'CGST + SGST' : 'IGST'}</span>
                    <span className="font-mono tabular-nums">{formatINR(cartTotals.taxTotal, true)}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-bold text-slate-900 pt-1.5 border-t border-slate-200">
                  <span>Grand Total</span>
                  <span className="font-mono tabular-nums">{formatINR(cartTotals.grandTotal, true)}</span>
                </div>
                {cartTotals.balanceDue > 0 && (
                  <div className="flex justify-between text-xs font-semibold text-amber-700">
                    <span>Balance Due (Credit)</span>
                    <span className="font-mono tabular-nums">{formatINR(cartTotals.balanceDue, true)}</span>
                  </div>
                )}
              </div>

              <button
                type="button"
                disabled={submittingSale || cart.length === 0}
                onClick={handleCompleteSale}
                className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-50"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{submittingSale ? 'Generating Invoice...' : `Complete Sale · ${formatINR(cartTotals.grandTotal)}`}</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Sales History View */
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                placeholder="Search invoice # or customer..."
                className="w-full min-h-[40px] pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 bg-white text-sm"
              />
            </div>

            <div className="inline-flex items-center p-1 bg-slate-200/70 rounded-lg self-start">
              {(
                [
                  { id: 'all', label: 'All' },
                  { id: 'completed', label: 'Completed' },
                  { id: 'due', label: 'Balance Due' },
                  { id: 'returned', label: 'Returns/Cancel' },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setStatusFilter(f.id)}
                  className={`min-h-[34px] px-3 py-1 text-xs font-medium rounded-md cursor-pointer ${
                    statusFilter === f.id ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {filteredSales.length === 0 ? (
            <EmptyState
              icon={ReceiptIndianRupee}
              title="No matching sales invoices"
              description="Bills you create in the POS will appear here with printable invoices and return controls."
              actionLabel="Create New Bill"
              onAction={() => setTab('pos')}
            />
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500">
                      <th className="py-3 px-4">Invoice</th>
                      <th className="py-3 px-4">Customer</th>
                      <th className="py-3 px-4">Payment</th>
                      <th className="py-3 px-4 text-right">Total</th>
                      <th className="py-3 px-4 text-right">Due</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {filteredSales.map((s) => (
                      <tr key={s.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4">
                          <div className="font-mono font-semibold text-slate-900">{s.invoiceNumber}</div>
                          <div className="text-xs text-slate-500">{formatDateIN(s.saleDate)}</div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-medium text-slate-900">{s.customerName}</div>
                          <div className="text-xs text-slate-400">
                            {s.items.length} item{s.items.length > 1 ? 's' : ''} · By {s.createdByName}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-xs uppercase font-medium text-slate-600">
                          {s.paymentMethod.replace('_', ' ')}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-semibold tabular-nums text-slate-900">
                          {formatINR(s.grandTotal, true)}
                        </td>
                        <td
                          className={`py-3 px-4 text-right font-mono tabular-nums ${
                            s.balanceDue > 0 ? 'text-amber-700 font-semibold' : 'text-slate-400'
                          }`}
                        >
                          {s.balanceDue > 0 ? formatINR(s.balanceDue, true) : '—'}
                        </td>
                        <td className="py-3 px-4 text-xs">
                          <span
                            className={`font-medium capitalize ${
                              s.status === 'completed'
                                ? 'text-emerald-700'
                                : s.status === 'returned'
                                  ? 'text-amber-700'
                                  : 'text-rose-600'
                            }`}
                          >
                            {s.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="inline-flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => setPreviewSale(s)}
                              className="min-h-[34px] px-2.5 py-1 rounded-md border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-100 inline-flex items-center gap-1 cursor-pointer"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              <span>Invoice</span>
                            </button>
                            {s.status === 'completed' && s.balanceDue > 0 && s.customerId && (
                              <button
                                type="button"
                                onClick={() => {
                                  setCollectTarget(s);
                                  setCollectAmount(String(s.balanceDue));
                                  setCollectMethod('upi');
                                  setCollectNote('');
                                  setCollectError(null);
                                }}
                                className="min-h-[34px] px-2.5 py-1 rounded-md bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-800 hover:bg-emerald-100 cursor-pointer"
                              >
                                Collect
                              </button>
                            )}
                            {s.status === 'completed' && (
                              <button
                                type="button"
                                onClick={() => {
                                  setReturnTarget(s);
                                  setReturnType('returned');
                                  setReturnReason('');
                                  setReturnError(null);
                                }}
                                title="Return or Cancel"
                                className="min-h-[34px] px-2.5 py-1 rounded-md border border-rose-200 text-xs font-medium text-rose-700 hover:bg-rose-50 inline-flex items-center gap-1 cursor-pointer"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                <span>Return</span>
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Quick Add Customer Modal */}
      <Modal
        open={quickCustOpen}
        onClose={() => setQuickCustOpen(false)}
        title="Quick Add Customer"
        subtitle="Add customer to attach credit or invoice history"
      >
        <form onSubmit={handleQuickAddCustomer} className="space-y-4">
          <FormErrorBanner message={qcError} />
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Customer Name *</label>
            <input
              type="text"
              required
              maxLength={FIELD_LIMITS.customerName.max}
              value={qcName}
              onChange={(e) => setQcName(e.target.value)}
              placeholder="e.g. Ramesh Kumar"
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Phone Number *</label>
            <input
              type="tel"
              required
              maxLength={FIELD_LIMITS.phone.max}
              value={qcPhone}
              onChange={(e) => setQcPhone(e.target.value)}
              placeholder="+91 98..."
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setQuickCustOpen(false)}
              className="min-h-[40px] px-4 rounded-lg border border-slate-200 text-sm cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={qcSaving}
              className="min-h-[40px] px-4 rounded-lg bg-emerald-600 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
            >
              {qcSaving ? 'Adding...' : 'Add Customer'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Printable Invoice Modal */}
      <Modal
        open={Boolean(previewSale)}
        onClose={() => setPreviewSale(null)}
        title={`Invoice ${previewSale?.invoiceNumber || ''}`}
        maxWidthClass="sm:max-w-2xl"
      >
        {previewSale && (
          <div className="space-y-4">
            <div id="printable-invoice" className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-5 text-slate-900">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-slate-200 pb-4">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">{activeBusiness?.name}</h2>
                  {activeBusiness?.address && (
                    <p className="text-xs text-slate-600">
                      {activeBusiness.address}
                      {activeBusiness.city ? `, ${activeBusiness.city}` : ''}
                      {activeBusiness.state ? `, ${activeBusiness.state}` : ''}
                      {activeBusiness.pincode ? ` - ${activeBusiness.pincode}` : ''}
                    </p>
                  )}
                  {activeBusiness?.phone && (
                    <p className="text-xs text-slate-600">Phone: {activeBusiness.phone}</p>
                  )}
                  {businessHasValidGstin && (
                    <p className="text-xs font-mono text-slate-700 mt-0.5">GSTIN: {activeBusiness?.gstin}</p>
                  )}
                </div>
                <div className="sm:text-right">
                  <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                    {previewSale.gstMode !== 'none' && businessHasValidGstin ? 'Tax Invoice' : 'Retail Bill'}
                  </div>
                  <div className="text-base font-mono font-bold text-slate-900">{previewSale.invoiceNumber}</div>
                  <div className="text-xs text-slate-500">{formatDateTimeIN(previewSale.saleDate)}</div>
                  {previewSale.status !== 'completed' && (
                    <div className="text-xs font-bold uppercase text-rose-600 mt-1">
                      STATUS: {previewSale.status}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row justify-between gap-2 text-xs bg-slate-50 rounded-lg p-3">
                <div>
                  <span className="text-slate-500">Billed To: </span>
                  <strong className="text-slate-900">{previewSale.customerName}</strong>
                  {previewSale.customerPhone && (
                    <span className="text-slate-600"> · {previewSale.customerPhone}</span>
                  )}
                </div>
                <div>
                  <span className="text-slate-500">Payment: </span>
                  <strong className="uppercase text-slate-900">{previewSale.paymentMethod.replace('_', ' ')}</strong>
                </div>
              </div>

              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="py-2 pr-2">Item</th>
                    <th className="py-2 px-2 text-right">Qty</th>
                    <th className="py-2 px-2 text-right">Rate</th>
                    <th className="py-2 px-2 text-right">Disc</th>
                    <th className="py-2 px-2 text-right">Tax</th>
                    <th className="py-2 pl-2 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {previewSale.items.map((item, idx) => (
                    <tr key={item.productId + idx}>
                      <td className="py-2 pr-2">
                        <div className="font-medium text-slate-900">{item.productName}</div>
                        <div className="text-[10px] font-mono text-slate-400">{item.sku}</div>
                      </td>
                      <td className="py-2 px-2 text-right font-mono">{item.quantity}</td>
                      <td className="py-2 px-2 text-right font-mono">{formatINR(item.unitPrice, true)}</td>
                      <td className="py-2 px-2 text-right font-mono">{formatINR(item.discountAmount, true)}</td>
                      <td className="py-2 px-2 text-right font-mono">
                        {formatINR(item.taxAmount, true)} ({item.gstRate}%)
                      </td>
                      <td className="py-2 pl-2 text-right font-mono font-semibold">
                        {formatINR(item.lineTotal, true)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="border-t border-slate-200 pt-3 flex flex-col sm:items-end space-y-1 text-xs">
                <div className="w-full sm:w-64 flex justify-between text-slate-600">
                  <span>Subtotal</span>
                  <span className="font-mono">{formatINR(previewSale.subtotal, true)}</span>
                </div>
                {previewSale.discountTotal > 0 && (
                  <div className="w-full sm:w-64 flex justify-between text-slate-600">
                    <span>Discount</span>
                    <span className="font-mono">-{formatINR(previewSale.discountTotal, true)}</span>
                  </div>
                )}
                {previewSale.gstMode === 'cgst_sgst' && (
                  <>
                    <div className="w-full sm:w-64 flex justify-between text-slate-600">
                      <span>CGST</span>
                      <span className="font-mono">{formatINR(previewSale.taxTotal / 2, true)}</span>
                    </div>
                    <div className="w-full sm:w-64 flex justify-between text-slate-600">
                      <span>SGST</span>
                      <span className="font-mono">{formatINR(previewSale.taxTotal / 2, true)}</span>
                    </div>
                  </>
                )}
                {previewSale.gstMode === 'igst' && (
                  <div className="w-full sm:w-64 flex justify-between text-slate-600">
                    <span>IGST</span>
                    <span className="font-mono">{formatINR(previewSale.taxTotal, true)}</span>
                  </div>
                )}
                <div className="w-full sm:w-64 flex justify-between text-sm font-bold text-slate-900 pt-1.5 border-t border-slate-200">
                  <span>Grand Total</span>
                  <span className="font-mono">{formatINR(previewSale.grandTotal, true)}</span>
                </div>
                <div className="w-full sm:w-64 flex justify-between text-slate-600">
                  <span>Paid</span>
                  <span className="font-mono">{formatINR(previewSale.amountPaid, true)}</span>
                </div>
                {previewSale.balanceDue > 0 && (
                  <div className="w-full sm:w-64 flex justify-between font-semibold text-amber-700">
                    <span>Balance Due</span>
                    <span className="font-mono">{formatINR(previewSale.balanceDue, true)}</span>
                  </div>
                )}
              </div>

              <div className="text-[11px] text-slate-400 pt-3 border-t border-slate-100 flex justify-between">
                <span>Generated via BIZORA</span>
                <span>Thank you for your business</span>
              </div>
            </div>

            <div className="flex justify-end gap-2.5 no-print">
              <button
                type="button"
                onClick={() => setPreviewSale(null)}
                className="min-h-[40px] px-4 rounded-lg border border-slate-200 text-sm text-slate-700 cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="min-h-[40px] px-4 rounded-lg bg-[#0B1528] hover:bg-slate-800 text-white text-sm font-medium inline-flex items-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Invoice</span>
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Return / Cancel Modal */}
      <Modal
        open={Boolean(returnTarget)}
        onClose={() => setReturnTarget(null)}
        title={`Return or Cancel · ${returnTarget?.invoiceNumber || ''}`}
        subtitle="Restores product stock and reverses unpaid customer dues atomically"
      >
        <form onSubmit={handleProcessReturn} className="space-y-4">
          <FormErrorBanner message={returnError} />

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Action Type</label>
            <select
              value={returnType}
              onChange={(e) => setReturnType(e.target.value as 'returned' | 'cancelled')}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white"
            >
              <option value="returned">Sales Return (Customer returned items)</option>
              <option value="cancelled">Order Cancellation (Void bill)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Reason *</label>
            <input
              type="text"
              required
              maxLength={FIELD_LIMITS.returnReason.max}
              value={returnReason}
              onChange={(e) => setReturnReason(e.target.value)}
              placeholder="e.g. Defective cable exchanged or billing error"
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setReturnTarget(null)}
              className="min-h-[40px] px-4 rounded-lg border border-slate-200 text-sm cursor-pointer"
            >
              Keep Invoice
            </button>
            <button
              type="submit"
              disabled={returning}
              className="min-h-[40px] px-4 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
            >
              {returning ? 'Processing...' : `Confirm ${returnType === 'returned' ? 'Return' : 'Cancellation'}`}
            </button>
          </div>
        </form>
      </Modal>

      {/* Collect Due Modal */}
      <Modal
        open={Boolean(collectTarget)}
        onClose={() => setCollectTarget(null)}
        title={`Collect Due · ${collectTarget?.invoiceNumber || ''}`}
        subtitle={`Customer: ${collectTarget?.customerName || ''} · Due: ${formatINR(collectTarget?.balanceDue || 0, true)}`}
      >
        <form onSubmit={handleCollectDue} className="space-y-4">
          <FormErrorBanner message={collectError} />

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Amount Received (₹) *</label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              max={collectTarget?.balanceDue}
              required
              value={collectAmount}
              onChange={(e) => setCollectAmount(e.target.value)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Payment Method</label>
            <select
              value={collectMethod}
              onChange={(e) => setCollectMethod(e.target.value as NonCreditPaymentMethod)}
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white"
            >
              <option value="upi">UPI</option>
              <option value="cash">Cash</option>
              <option value="card">Card</option>
              <option value="bank_transfer">Bank Transfer</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Reference / Note</label>
            <input
              type="text"
              maxLength={200}
              value={collectNote}
              onChange={(e) => setCollectNote(e.target.value)}
              placeholder="UPI ref or receipt note"
              className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCollectTarget(null)}
              className="min-h-[40px] px-4 rounded-lg border border-slate-200 text-sm cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={collecting}
              className="min-h-[40px] px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
            >
              {collecting ? 'Recording...' : 'Record Payment'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
