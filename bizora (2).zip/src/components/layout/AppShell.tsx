import React, { useState } from 'react';
import {
  BarChart3,
  Building2,
  ChevronDown,
  LayoutDashboard,
  LogOut,
  Menu,
  Package,
  Plus,
  ReceiptIndianRupee,
  Settings,
  Users,
  X,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

export type NavTab = 'dashboard' | 'inventory' | 'sales' | 'people' | 'reports' | 'settings';

interface AppShellProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onNewSaleShortcut: () => void;
  onNewBusinessModal: () => void;
  children: React.ReactNode;
}

export function AppShell({
  activeTab,
  onSelectTab,
  onNewSaleShortcut,
  onNewBusinessModal,
  children,
}: AppShellProps) {
  const { activeBusiness, memberships, role, actor, permissions, switchBusiness, logout } = useAuth();
  const [workspaceMenuOpen, setWorkspaceMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: Array<{
    id: NavTab;
    label: string;
    mobileLabel: string;
    icon: React.ComponentType<{ className?: string }>;
    visible: boolean;
  }> = [
    { id: 'dashboard', label: 'Dashboard', mobileLabel: 'Home', icon: LayoutDashboard, visible: true },
    { id: 'inventory', label: 'Inventory', mobileLabel: 'Stock', icon: Package, visible: true },
    { id: 'sales', label: 'Sales & Billing', mobileLabel: 'Billing', icon: ReceiptIndianRupee, visible: permissions.canBill },
    { id: 'people', label: 'Customers & Staff', mobileLabel: 'People', icon: Users, visible: permissions.canViewCustomers || permissions.canManageStaff },
    { id: 'reports', label: 'Reports & BI', mobileLabel: 'Reports', icon: BarChart3, visible: permissions.canViewFinance || permissions.canManageInventory },
    { id: 'settings', label: 'Business Settings', mobileLabel: 'Settings', icon: Settings, visible: permissions.canManageSettings },
  ];

  const visibleNav = navItems.filter((n) => n.visible);
  const mobileBottomNav = visibleNav.slice(0, 5);
  const activeTitle = navItems.find((n) => n.id === activeTab)?.label || 'Dashboard';

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row">
      {/* Desktop Sidebar (Deep Navy) */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-[#0B1528] text-slate-200 border-r border-slate-800 z-30 no-print">
        {/* Brand */}
        <div className="h-14 px-5 flex items-center justify-between border-b border-slate-800/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white font-display font-bold flex items-center justify-center text-sm">
              B
            </div>
            <span className="font-display font-bold text-lg tracking-tight text-white">BIZORA</span>
          </div>
          {activeBusiness?.isDemo && (
            <span className="text-[11px] font-medium text-amber-300">Demo</span>
          )}
        </div>

        {/* Workspace Switcher */}
        <div className="p-3 border-b border-slate-800/80 relative">
          <button
            type="button"
            onClick={() => setWorkspaceMenuOpen((o) => !o)}
            className="w-full px-3 py-2 rounded-lg bg-slate-900/70 hover:bg-slate-800/90 border border-slate-800 text-left flex items-center justify-between gap-2 transition-colors cursor-pointer"
          >
            <div className="min-w-0">
              <div className="text-xs font-semibold text-white truncate">{activeBusiness?.name}</div>
              <div className="text-[11px] text-slate-400 truncate capitalize">
                {role} {activeBusiness?.isDemo ? '· Sample Sandbox' : '· Live Store'}
              </div>
            </div>
            <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
          </button>

          {workspaceMenuOpen && (
            <div className="absolute left-3 right-3 top-full mt-1 bg-[#0F1D36] border border-slate-700 rounded-xl shadow-xl py-1.5 z-40">
              {memberships.map((m) => (
                <button
                  key={m.businessId}
                  type="button"
                  onClick={() => {
                    setWorkspaceMenuOpen(false);
                    void switchBusiness(m.businessId);
                  }}
                  className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between gap-2 hover:bg-slate-800 cursor-pointer ${
                    m.businessId === activeBusiness?.id ? 'text-emerald-400 font-semibold' : 'text-slate-200'
                  }`}
                >
                  <span className="truncate">{m.businessName}</span>
                  <span className="text-[10px] text-slate-400 capitalize shrink-0">{m.role}</span>
                </button>
              ))}
              <div className="border-t border-slate-800 mt-1 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setWorkspaceMenuOpen(false);
                    onNewBusinessModal();
                  }}
                  className="w-full px-3 py-2 text-left text-xs text-emerald-400 hover:bg-slate-800 flex items-center gap-1.5 font-medium cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add or Launch Workspace</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Nav Links */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {visibleNav.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`w-full min-h-[42px] px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-3 transition-colors cursor-pointer whitespace-nowrap ${
                  active
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-300 hover:bg-slate-800/70 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* User Footer */}
        <div className="p-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="text-xs font-medium text-white truncate">{actor?.name}</div>
            <div className="text-[11px] text-slate-400 truncate">{actor?.email}</div>
          </div>
          <button
            type="button"
            onClick={logout}
            title="Sign out"
            className="min-w-[36px] min-h-[36px] rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 flex items-center justify-center transition-colors cursor-pointer shrink-0"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </aside>

      {/* Main Column */}
      <div className="flex-1 lg:pl-64 flex flex-col min-h-screen">
        {/* Desktop Top Header & Mobile Compact Header (52px mobile, 56px desktop) */}
        <header className="sticky top-0 z-20 h-[52px] lg:h-14 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-4 no-print">
          <div className="flex items-center gap-3 min-w-0">
            <div className="lg:hidden w-7 h-7 rounded-md bg-[#0B1528] text-white font-display font-bold flex items-center justify-center text-xs shrink-0">
              B
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-semibold text-slate-900 truncate">{activeTitle}</h1>
                {activeBusiness?.isDemo && (
                  <span className="text-[11px] font-medium text-amber-700 hidden sm:inline">
                    · Demo Environment
                  </span>
                )}
              </div>
              <div className="text-[11px] text-slate-500 truncate lg:hidden">
                {activeBusiness?.name}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {permissions.canBill && (
              <button
                type="button"
                onClick={onNewSaleShortcut}
                className="min-h-[38px] px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>New Bill</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open workspace menu"
              className="lg:hidden min-w-[40px] min-h-[40px] rounded-lg border border-slate-200 text-slate-700 flex items-center justify-center cursor-pointer"
            >
              <Menu className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Demo Environment Notice Strip (inline, scrollable, not sticky) */}
        {activeBusiness?.isDemo && (
          <div className="bg-amber-50 border-b border-amber-200 px-4 sm:px-6 py-2 text-xs text-amber-900 flex flex-wrap items-center justify-between gap-2 no-print">
            <span>
              Viewing <strong>Demo Workspace</strong> (sample Indian electronics shop data). Switch or create your real store anytime.
            </span>
            <button
              type="button"
              onClick={onNewBusinessModal}
              className="font-semibold text-amber-950 underline hover:no-underline cursor-pointer"
            >
              Create Real Business
            </button>
          </div>
        )}

        {/* Workspace Content */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-5 sm:py-6 pb-24 lg:pb-8">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar (Fixed, 60px high, <=15% mobile height) */}
      <nav
        aria-label="Mobile navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-30 h-[60px] bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-flow-col auto-cols-fr items-center px-1 no-print"
      >
        {mobileBottomNav.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`min-h-[48px] flex flex-col items-center justify-center gap-0.5 transition-colors cursor-pointer ${
                active ? 'text-emerald-700 font-semibold' : 'text-slate-500'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] leading-tight whitespace-nowrap">{item.mobileLabel}</span>
            </button>
          );
        })}
      </nav>

      {/* Mobile Workspace & Settings Sheet */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex items-end">
          <div className="w-full bg-white rounded-t-3xl p-5 space-y-5 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-600" />
                <span className="text-sm font-semibold text-slate-900">Workspace & Account</span>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-medium text-slate-500">Switch Business</div>
              {memberships.map((m) => (
                <button
                  key={m.businessId}
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    void switchBusiness(m.businessId);
                  }}
                  className={`w-full min-h-[44px] px-3.5 py-2 rounded-xl border text-left text-sm flex items-center justify-between cursor-pointer ${
                    m.businessId === activeBusiness?.id
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-semibold'
                      : 'border-slate-200 text-slate-700'
                  }`}
                >
                  <span className="truncate">{m.businessName}</span>
                  <span className="text-xs capitalize text-slate-500">{m.role}</span>
                </button>
              ))}
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onNewBusinessModal();
                }}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-dashed border-slate-300 text-sm font-medium text-emerald-700 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Create or Launch Workspace</span>
              </button>
            </div>

            {permissions.canManageSettings && (
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onSelectTab('settings');
                }}
                className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-100 text-slate-800 text-sm font-medium flex items-center justify-center gap-2 cursor-pointer"
              >
                <Settings className="w-4 h-4" />
                <span>Business & GST Settings</span>
              </button>
            )}

            <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
              <div className="min-w-0">
                <div className="text-xs font-semibold text-slate-900 truncate">{actor?.name}</div>
                <div className="text-[11px] text-slate-500 truncate">{actor?.email} · {role}</div>
              </div>
              <button
                type="button"
                onClick={logout}
                className="min-h-[40px] px-3.5 py-2 rounded-lg border border-rose-200 text-rose-700 text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign out</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
