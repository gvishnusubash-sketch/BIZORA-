import React from 'react';
import type { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string;
  subtext?: string;
  tone?: 'default' | 'emerald' | 'amber' | 'rose';
}

export function StatCard({ label, value, subtext, tone = 'default' }: StatCardProps) {
  const valueTone =
    tone === 'emerald'
      ? 'text-emerald-700'
      : tone === 'amber'
        ? 'text-amber-700'
        : tone === 'rose'
          ? 'text-rose-700'
          : 'text-slate-900';

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col justify-between gap-2">
      <div className="text-xs font-medium text-slate-500">{label}</div>
      <div className={`text-xl sm:text-2xl font-bold tracking-tight tabular-nums font-mono ${valueTone}`}>
        {value}
      </div>
      {subtext && <div className="text-xs text-slate-500 truncate">{subtext}</div>}
    </div>
  );
}

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}

export function EmptyState({ icon: Icon, title, description, actionLabel, onAction }: EmptyStateProps) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-8 sm:p-10 text-center flex flex-col items-center justify-center">
      <div className="w-11 h-11 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center mb-3">
        <Icon className="w-5 h-5" />
      </div>
      <h3 className="text-sm font-semibold text-slate-900">{title}</h3>
      <p className="mt-1 text-xs sm:text-sm text-slate-500 max-w-sm leading-relaxed">{description}</p>
      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className="mt-4 min-h-[40px] px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium transition-colors cursor-pointer"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}

export function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden animate-pulse">
      <div className="h-10 bg-slate-50 border-b border-slate-200" />
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="h-12 border-b border-slate-100 last:border-b-0 px-4 flex items-center gap-4">
          <div className="h-3.5 bg-slate-200 rounded w-1/4" />
          <div className="h-3.5 bg-slate-100 rounded w-1/3" />
          <div className="h-3.5 bg-slate-100 rounded w-1/6 ml-auto" />
        </div>
      ))}
    </div>
  );
}

export function FormErrorBanner({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div
      role="alert"
      className="rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs sm:text-sm text-rose-700"
    >
      {message}
    </div>
  );
}
