import { useState } from 'react';
import { formatINR, formatINRCompact } from '../../lib/formatters';

export interface TrendPoint {
  label: string;
  sales: number;
  expenses: number;
}

export function RevenueTrendChart({ data }: { data: TrendPoint[] }) {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  if (data.length === 0) {
    return (
      <div className="h-56 flex items-center justify-center text-xs text-slate-500">
        No transactions recorded for this period.
      </div>
    );
  }

  const width = 640;
  const height = 220;
  const padLeft = 56;
  const padRight = 18;
  const padTop = 18;
  const padBottom = 30;
  const innerW = width - padLeft - padRight;
  const innerH = height - padTop - padBottom;

  const maxVal = Math.max(
    100,
    ...data.map((d) => Math.max(d.sales, d.expenses))
  );
  const niceMax = Math.ceil(maxVal * 1.15);

  const xFor = (i: number) =>
    data.length === 1 ? padLeft + innerW / 2 : padLeft + (i / (data.length - 1)) * innerW;
  const yFor = (val: number) => padTop + innerH - (val / niceMax) * innerH;

  const salesPoints = data.map((d, i) => `${xFor(i)},${yFor(d.sales)}`).join(' ');
  const expensePoints = data.map((d, i) => `${xFor(i)},${yFor(d.expenses)}`).join(' ');

  const areaPath =
    data.length > 1
      ? `M ${xFor(0)},${padTop + innerH} L ${data
          .map((d, i) => `${xFor(i)},${yFor(d.sales)}`)
          .join(' L ')} L ${xFor(data.length - 1)},${padTop + innerH} Z`
      : '';

  const gridTicks = [0, 0.25, 0.5, 0.75, 1];
  const activePoint = hoveredIdx !== null ? data[hoveredIdx] : null;

  return (
    <div className="relative select-none">
      <div className="flex items-center justify-between gap-4 mb-3">
        <div className="flex items-center gap-4 text-xs text-slate-600">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-emerald-600 inline-block" />
            Sales
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-[#0B1528] inline-block" />
            Expenses
          </span>
        </div>
        {activePoint ? (
          <div className="text-xs font-mono tabular-nums text-slate-700">
            {activePoint.label}: Sales {formatINR(activePoint.sales)} · Exp {formatINR(activePoint.expenses)}
          </div>
        ) : (
          <div className="text-xs text-slate-400">Hover points for exact INR</div>
        )}
      </div>

      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-52 overflow-visible"
        role="img"
        aria-label="Sales and expenses trend chart"
      >
        <defs>
          <linearGradient id="bizoraSalesFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#059669" stopOpacity="0.16" />
            <stop offset="100%" stopColor="#059669" stopOpacity="0.0" />
          </linearGradient>
        </defs>

        {gridTicks.map((t) => {
          const y = padTop + innerH - t * innerH;
          const val = niceMax * t;
          return (
            <g key={t}>
              <line
                x1={padLeft}
                x2={width - padRight}
                y1={y}
                y2={y}
                stroke="#e2e8f0"
                strokeWidth="1"
              />
              <text
                x={padLeft - 8}
                y={y + 4}
                textAnchor="end"
                className="fill-slate-400 text-[10px] font-mono"
              >
                {formatINRCompact(val)}
              </text>
            </g>
          );
        })}

        {areaPath && <path d={areaPath} fill="url(#bizoraSalesFill)" />}

        {data.length > 1 && (
          <>
            <polyline
              fill="none"
              stroke="#0B1528"
              strokeWidth="2"
              strokeDasharray="4 3"
              points={expensePoints}
            />
            <polyline
              fill="none"
              stroke="#059669"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={salesPoints}
            />
          </>
        )}

        {data.map((d, i) => {
          const cx = xFor(i);
          const cySales = yFor(d.sales);
          const cyExp = yFor(d.expenses);
          const showLabel =
            data.length <= 8 || i === 0 || i === data.length - 1 || i % Math.ceil(data.length / 6) === 0;
          return (
            <g
              key={d.label + i}
              onMouseEnter={() => setHoveredIdx(i)}
              onMouseLeave={() => setHoveredIdx(null)}
              className="cursor-pointer"
            >
              <rect
                x={cx - 14}
                y={padTop}
                width={28}
                height={innerH + 20}
                fill="transparent"
              />
              {hoveredIdx === i && (
                <line
                  x1={cx}
                  x2={cx}
                  y1={padTop}
                  y2={padTop + innerH}
                  stroke="#cbd5e1"
                  strokeWidth="1"
                />
              )}
              <circle
                cx={cx}
                cy={cyExp}
                r={hoveredIdx === i ? 4.5 : 3}
                fill="#0B1528"
                stroke="#ffffff"
                strokeWidth="1.5"
              />
              <circle
                cx={cx}
                cy={cySales}
                r={hoveredIdx === i ? 5 : 3.5}
                fill="#059669"
                stroke="#ffffff"
                strokeWidth="1.5"
              />
              {showLabel && (
                <text
                  x={cx}
                  y={height - 6}
                  textAnchor="middle"
                  className="fill-slate-500 text-[10px]"
                >
                  {d.label}
                </text>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
}

export interface BreakdownItem {
  label: string;
  value: number;
  sublabel?: string;
}

export function HorizontalBarBreakdown({
  items,
  emptyText = 'No breakdown data available.',
}: {
  items: BreakdownItem[];
  emptyText?: string;
}) {
  if (items.length === 0) {
    return <div className="py-8 text-center text-xs text-slate-500">{emptyText}</div>;
  }
  const maxVal = Math.max(1, ...items.map((i) => i.value));
  const total = items.reduce((acc, i) => acc + i.value, 0);

  return (
    <div className="space-y-3">
      {items.map((item) => {
        const pct = total > 0 ? Math.round((item.value / total) * 100) : 0;
        const barWidth = Math.max(4, Math.round((item.value / maxVal) * 100));
        return (
          <div key={item.label} className="space-y-1">
            <div className="flex items-center justify-between gap-2 text-xs">
              <span className="font-medium text-slate-700 truncate">{item.label}</span>
              <span className="font-mono tabular-nums text-slate-900 shrink-0">
                {formatINR(item.value)} <span className="text-slate-400">({pct}%)</span>
              </span>
            </div>
            <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
              <div
                className="h-full rounded-full bg-emerald-600 transition-all duration-200"
                style={{ width: `${barWidth}%` }}
              />
            </div>
            {item.sublabel && <div className="text-[11px] text-slate-400">{item.sublabel}</div>}
          </div>
        );
      })}
    </div>
  );
}
