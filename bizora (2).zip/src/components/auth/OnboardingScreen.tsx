import React, { useState } from 'react';
import { Building2, LogOut, Sparkles, UserCheck } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { FIELD_LIMITS, isValidGstin, isValidPhone } from '../../lib/validation';
import { FormErrorBanner } from '../ui/DataPrimitives';

export function OnboardingScreen() {
  const { user, pendingInvites, createBusiness, launchDemoStore, acceptInvite, logout } = useAuth();

  const [name, setName] = useState('');
  const [tagline, setTagline] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [stateName, setStateName] = useState('');
  const [invoicePrefix, setInvoicePrefix] = useState('INV');
  const [gstEnabled, setGstEnabled] = useState(true);
  const [gstin, setGstin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [demoLoading, setDemoLoading] = useState(false);
  const [acceptingId, setAcceptingId] = useState<string | null>(null);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (name.trim().length < FIELD_LIMITS.businessName.min) {
      setError('Business name must be at least 2 characters.');
      return;
    }
    if (phone.trim() && !isValidPhone(phone)) {
      setError('Please enter a valid contact phone number (6–20 digits).');
      return;
    }
    if (gstin.trim() && !isValidGstin(gstin)) {
      setError('Invalid GSTIN format. Expected 15-character format like 29AABCU9603R1ZM.');
      return;
    }
    if (!invoicePrefix.trim()) {
      setError('Invoice prefix is required (e.g. INV).');
      return;
    }

    setSubmitting(true);
    try {
      await createBusiness({
        name: name.trim(),
        tagline: tagline.trim(),
        phone: phone.trim(),
        city: city.trim(),
        state: stateName.trim(),
        invoicePrefix: invoicePrefix.trim().toUpperCase(),
        gstEnabled,
        gstin: gstin.trim().toUpperCase(),
        email: user?.email || '',
        isDemo: false,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create business workspace.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleLaunchDemo = async () => {
    setError(null);
    setDemoLoading(true);
    try {
      await launchDemoStore();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not initialize demo workspace.');
    } finally {
      setDemoLoading(false);
    }
  };

  const handleAcceptInvite = async (inviteId: string) => {
    const invite = pendingInvites.find((i) => i.id === inviteId);
    if (!invite) return;
    setError(null);
    setAcceptingId(inviteId);
    try {
      await acceptInvite(invite);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to accept staff invitation.');
    } finally {
      setAcceptingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white border-b border-slate-200 px-4 sm:px-8 h-14 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#0B1528] text-white font-display font-bold flex items-center justify-center text-sm">
            B
          </div>
          <span className="font-display font-bold text-lg text-slate-900">BIZORA</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="hidden sm:inline text-xs text-slate-500">{user?.email}</span>
          <button
            type="button"
            onClick={logout}
            className="min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign out</span>
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-8 sm:py-12 space-y-8">
        <div className="space-y-1.5">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Set up your business workspace</h1>
          <p className="text-sm text-slate-600">
            Create your shop ledger or explore BIZORA using a clearly labelled sample Indian electronics store.
          </p>
        </div>

        <FormErrorBanner message={error} />

        {pendingInvites.length > 0 && (
          <div className="bg-white border border-emerald-200 rounded-2xl p-5 space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-emerald-900">
              <UserCheck className="w-4 h-4 text-emerald-600" />
              <span>Pending Team Invitations</span>
            </div>
            <div className="divide-y divide-slate-100">
              {pendingInvites.map((inv) => (
                <div key={inv.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold text-slate-900">{inv.businessName}</div>
                    <div className="text-xs text-slate-500">
                      Role assigned: <span className="font-medium text-slate-700 capitalize">{inv.role}</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={acceptingId === inv.id}
                    onClick={() => handleAcceptInvite(inv.id)}
                    className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
                  >
                    {acceptingId === inv.id ? 'Joining...' : 'Accept & Join Business'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Create Real Business Form */}
          <form
            onSubmit={handleCreate}
            className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4"
          >
            <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
              <Building2 className="w-5 h-5 text-emerald-600" />
              <div>
                <h2 className="text-base font-semibold text-slate-900">Create Your Business</h2>
                <p className="text-xs text-slate-500">Start with a clean production ledger for your store</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Business / Shop Name *
                </label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.businessName.max}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Sri Sai Mobile & Electronics"
                  className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Business Category / Tagline
                </label>
                <input
                  type="text"
                  maxLength={FIELD_LIMITS.tagline.max}
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  placeholder="e.g. Mobile Accessories, Chargers & Retail"
                  className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Phone Number</label>
                <input
                  type="tel"
                  maxLength={FIELD_LIMITS.phone.max}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98450 12345"
                  className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Invoice Prefix *</label>
                <input
                  type="text"
                  required
                  maxLength={FIELD_LIMITS.invoicePrefix.max}
                  value={invoicePrefix}
                  onChange={(e) => setInvoicePrefix(e.target.value.toUpperCase())}
                  placeholder="INV"
                  className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono uppercase focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">City</label>
                <input
                  type="text"
                  maxLength={FIELD_LIMITS.city.max}
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="Bengaluru"
                  className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">State</label>
                <input
                  type="text"
                  maxLength={FIELD_LIMITS.state.max}
                  value={stateName}
                  onChange={(e) => setStateName(e.target.value)}
                  placeholder="Karnataka"
                  className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                />
              </div>

              <div className="sm:col-span-2 pt-1">
                <label className="inline-flex items-center gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={gstEnabled}
                    onChange={(e) => setGstEnabled(e.target.checked)}
                    className="w-4 h-4 accent-emerald-600 rounded"
                  />
                  <span className="text-sm font-medium text-slate-800">Enable GST calculation on bills</span>
                </label>
              </div>

              {gstEnabled && (
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    GSTIN (Optional — 15-character format validated)
                  </label>
                  <input
                    type="text"
                    maxLength={15}
                    value={gstin}
                    onChange={(e) => setGstin(e.target.value.toUpperCase())}
                    placeholder="29AABCU9603R1ZM"
                    className="w-full min-h-[42px] px-3 py-2 rounded-lg border border-slate-200 text-sm font-mono uppercase focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                  />
                  <p className="mt-1 text-[11px] text-slate-500">
                    GST calculations assist billing estimates. Verify statutory filings with your Chartered Accountant or GST portal.
                  </p>
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={submitting || demoLoading}
              className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold transition-colors cursor-pointer disabled:opacity-50"
            >
              {submitting ? 'Creating Workspace...' : 'Create Business Workspace'}
            </button>
          </form>

          {/* Clearly Labelled Demo Environment Card */}
          <div className="lg:col-span-5 bg-[#0B1528] text-white rounded-2xl p-5 sm:p-6 space-y-5">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-medium text-emerald-400">
                <Sparkles className="w-4 h-4" />
                <span>Sample Sandbox Environment</span>
              </div>
              <h2 className="text-lg font-semibold text-white">Explore with Demo Store Data</h2>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Launch a clearly labelled demo business (<span className="font-medium text-white">Kaveri Mobile & Tech Mart</span>) pre-populated in your database with 7 SKUs, GST invoices, customer credit balances, and operating expenses.
              </p>
            </div>

            <div className="border-t border-slate-800 pt-4 space-y-2 text-xs text-slate-300">
              <div>· Every transaction runs on live Firestore persistence</div>
              <div>· Marked as a Demo Workspace so it never mixes with real books</div>
              <div>· Create your own real business anytime from Settings</div>
            </div>

            <button
              type="button"
              onClick={handleLaunchDemo}
              disabled={demoLoading || submitting}
              className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-white text-slate-900 hover:bg-slate-100 text-sm font-semibold transition-colors cursor-pointer disabled:opacity-50"
            >
              {demoLoading ? 'Seeding Demo Store...' : 'Launch Demo Store'}
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
