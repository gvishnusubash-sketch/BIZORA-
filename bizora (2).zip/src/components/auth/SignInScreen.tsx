import { useState } from 'react';
import { ArrowRight, Check, ShieldCheck, Store } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { FormErrorBanner } from '../ui/DataPrimitives';

export function SignInScreen() {
  const { signInWithGoogle, authError } = useAuth();
  const [signingIn, setSigningIn] = useState(false);
  const [imgFailed, setImgFailed] = useState(false);

  const handleSignIn = async () => {
    setSigningIn(true);
    try {
      await signInWithGoogle();
    } finally {
      setSigningIn(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:grid lg:grid-cols-12">
      {/* Left / Primary Auth Panel */}
      <div className="lg:col-span-6 xl:col-span-5 bg-[#0B1528] text-white flex flex-col justify-between p-6 sm:p-10 lg:p-12">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center font-display font-bold text-lg text-white">
              B
            </div>
            <span className="font-display font-bold text-xl tracking-tight text-white">BIZORA</span>
          </div>
          <span className="text-xs text-slate-400">India SMB Suite</span>
        </div>

        <div className="my-10 lg:my-auto max-w-md space-y-6">
          <div className="space-y-3">
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white [text-wrap:balance]">
              Your Business. Under Control.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Billing, GST invoices, stock alerts, customer credit balances, and profit reports in one fast workspace built for Indian retail shops and wholesalers.
            </p>
          </div>

          <ul className="space-y-2.5 text-sm text-slate-200">
            <li className="flex items-center gap-2.5">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Instant INR billing with UPI, Cash, Card, and Credit tracking</span>
            </li>
            <li className="flex items-center gap-2.5">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Real-time stock adjustments and low-stock supplier alerts</span>
            </li>
            <li className="flex items-center gap-2.5">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Role-based staff access with isolated business records</span>
            </li>
          </ul>

          <FormErrorBanner message={authError} />

          <div className="pt-2 space-y-3">
            <button
              type="button"
              onClick={handleSignIn}
              disabled={signingIn}
              className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm flex items-center justify-center gap-2.5 transition-colors cursor-pointer disabled:opacity-60"
            >
              <span>{signingIn ? 'Connecting Google Account...' : 'Continue with Google'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Secured by Firebase Authentication with per-business data isolation</span>
            </div>
          </div>
        </div>

        <div className="text-xs text-slate-400 flex items-center justify-between gap-4 pt-6 border-t border-slate-800">
          <span>BIZORA Operations Platform</span>
          <span>INR (₹) · GST Ready</span>
        </div>
      </div>

      {/* Right / Visual Retail Context */}
      <div className="lg:col-span-6 xl:col-span-7 p-6 sm:p-10 lg:p-12 flex flex-col justify-center bg-slate-50">
        <div className="max-w-2xl mx-auto w-full space-y-6">
          <div className="rounded-2xl overflow-hidden border border-slate-200 bg-white">
            {!imgFailed ? (
              <img
                src="/src/assets/images/bizora_retail_counter_1795595650426.jpg"
                alt="Modern Indian mobile accessories and electronics retail store counter"
                referrerPolicy="no-referrer"
                onError={() => setImgFailed(true)}
                className="w-full aspect-[4/3] object-cover"
              />
            ) : (
              <div className="w-full aspect-[4/3] bg-gradient-to-br from-slate-100 to-emerald-50 flex flex-col items-center justify-center p-8 text-center">
                <Store className="w-12 h-12 text-emerald-700 mb-3" />
                <p className="text-sm font-semibold text-slate-800">BIZORA Retail & Wholesale Workspace</p>
                <p className="text-xs text-slate-500 mt-1">Mobile Accessories · Electronics · Local Retail</p>
              </div>
            )}
            <div className="p-5 sm:p-6 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-900">Built for daily shopfloor speed</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Works seamlessly on Android phones at the counter, tablets, and back-office desktops.
                </p>
              </div>
              <div className="text-xs font-mono text-emerald-700 font-medium shrink-0">
                5 Integrated Modules
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
