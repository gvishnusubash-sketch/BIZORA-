import React, { createContext, useContext, useEffect, useState } from 'react';
import type { Unsubscribe } from 'firebase/firestore';
import { subscribeCollection } from '../services/bizoraService';
import type {
  ActivityLog,
  Customer,
  Expense,
  Payment,
  Product,
  Sale,
  StaffMember,
  StockMovement,
} from '../types/bizora';
import { useAuth } from './AuthContext';

interface BusinessDataContextValue {
  products: Product[];
  stockMovements: StockMovement[];
  customers: Customer[];
  sales: Sale[];
  payments: Payment[];
  expenses: Expense[];
  staff: StaffMember[];
  activityLogs: ActivityLog[];
  loading: boolean;
}

const BusinessDataContext = createContext<BusinessDataContextValue | null>(null);

export function BusinessDataProvider({ children }: { children: React.ReactNode }) {
  const { activeBusiness, role, permissions } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [stockMovements, setStockMovements] = useState<StockMovement[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const businessId = activeBusiness?.id;
    if (!businessId || !role) {
      setProducts([]);
      setStockMovements([]);
      setCustomers([]);
      setSales([]);
      setPayments([]);
      setExpenses([]);
      setStaff([]);
      setActivityLogs([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    const unsubs: Unsubscribe[] = [];

    // All active members can read products & stock movements
    let productsReady = false;
    unsubs.push(
      subscribeCollection<Product>(
        `businesses/${businessId}/products`,
        (list) => {
          setProducts(list);
          if (!productsReady) {
            productsReady = true;
            setLoading(false);
          }
        },
        'name',
        'asc'
      )
    );

    unsubs.push(
      subscribeCollection<StockMovement>(
        `businesses/${businessId}/stockMovements`,
        setStockMovements,
        'createdAt',
        'desc'
      )
    );

    // Billing staff (owner, manager, cashier) can read customers, sales, payments
    if (permissions.canBill) {
      unsubs.push(
        subscribeCollection<Customer>(
          `businesses/${businessId}/customers`,
          setCustomers,
          'name',
          'asc'
        )
      );
      unsubs.push(
        subscribeCollection<Sale>(
          `businesses/${businessId}/sales`,
          setSales,
          'saleDate',
          'desc'
        )
      );
      unsubs.push(
        subscribeCollection<Payment>(
          `businesses/${businessId}/payments`,
          setPayments,
          'paymentDate',
          'desc'
        )
      );
    } else {
      setCustomers([]);
      setSales([]);
      setPayments([]);
    }

    // Finance & Staff restricted to owner and manager
    if (permissions.canViewFinance) {
      unsubs.push(
        subscribeCollection<Expense>(
          `businesses/${businessId}/expenses`,
          setExpenses,
          'expenseDate',
          'desc'
        )
      );
      unsubs.push(
        subscribeCollection<StaffMember>(
          `businesses/${businessId}/staff`,
          setStaff,
          'name',
          'asc'
        )
      );
      unsubs.push(
        subscribeCollection<ActivityLog>(
          `businesses/${businessId}/activityLogs`,
          setActivityLogs,
          'createdAt',
          'desc'
        )
      );
    } else {
      setExpenses([]);
      setStaff([]);
      setActivityLogs([]);
    }

    return () => {
      for (const u of unsubs) u();
    };
  }, [activeBusiness?.id, role, permissions.canBill, permissions.canViewFinance]);

  return (
    <BusinessDataContext.Provider
      value={{
        products,
        stockMovements,
        customers,
        sales,
        payments,
        expenses,
        staff,
        activityLogs,
        loading,
      }}
    >
      {children}
    </BusinessDataContext.Provider>
  );
}

export function useBusinessData(): BusinessDataContextValue {
  const ctx = useContext(BusinessDataContext);
  if (!ctx) throw new Error('useBusinessData must be used within BusinessDataProvider');
  return ctx;
}
