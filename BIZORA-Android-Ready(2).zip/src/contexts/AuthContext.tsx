import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import {
  acceptBusinessInvite,
  createBusinessWorkspace,
  createDemoBusinessWithSeedData,
  ensureUserProfile,
  setActiveBusinessForUser,
  subscribePendingInvites,
  subscribeUserMemberships,
  type ActorContext,
  type CreateBusinessInput,
} from '../services/bizoraService';
import type {
  Business,
  BusinessInvite,
  BusinessMember,
  Role,
  UserMembership,
  UserProfile,
} from '../types/bizora';

interface AuthContextValue {
  user: User | null;
  profile: UserProfile | null;
  memberships: UserMembership[];
  pendingInvites: BusinessInvite[];
  activeBusiness: Business | null;
  activeMember: BusinessMember | null;
  role: Role | null;
  actor: ActorContext | null;
  authLoading: boolean;
  workspaceLoading: boolean;
  authError: string | null;
  permissions: {
    canViewDashboard: boolean;
    canManageInventory: boolean;
    canAdjustStock: boolean;
    canBill: boolean;
    canViewCustomers: boolean;
    canViewFinance: boolean;
    canManageStaff: boolean;
    canManageSettings: boolean;
  };
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  switchBusiness: (businessId: string) => Promise<void>;
  createBusiness: (input: CreateBusinessInput) => Promise<string>;
  launchDemoStore: () => Promise<string>;
  acceptInvite: (invite: BusinessInvite) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [memberships, setMemberships] = useState<UserMembership[]>([]);
  const [pendingInvites, setPendingInvites] = useState<BusinessInvite[]>([]);
  const [activeBusiness, setActiveBusiness] = useState<Business | null>(null);
  const [activeMember, setActiveMember] = useState<BusinessMember | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [workspaceLoading, setWorkspaceLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      setAuthError(null);
      if (!firebaseUser) {
        setUser(null);
        setProfile(null);
        setMemberships([]);
        setPendingInvites([]);
        setActiveBusiness(null);
        setActiveMember(null);
        setAuthLoading(false);
        return;
      }

      if (!firebaseUser.email || !firebaseUser.emailVerified) {
        setAuthError('Please sign in with a verified Google email account.');
        setUser(null);
        setAuthLoading(false);
        return;
      }

      setUser(firebaseUser);
      try {
        await ensureUserProfile({
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          displayName: firebaseUser.displayName,
        });
      } catch (err) {
        setAuthError(err instanceof Error ? err.message : 'Unable to load user profile.');
      } finally {
        setAuthLoading(false);
      }
    });

    return () => unsub();
  }, []);

  // Subscribe to user profile, memberships, and pending invites when signed in
  useEffect(() => {
    if (!user?.uid || !user.email) return;

    const unsubProfile = onSnapshot(
      doc(db, 'users', user.uid),
      (snap) => {
        if (snap.metadata.hasPendingWrites) return;
        if (snap.exists()) {
          setProfile(snap.data() as UserProfile);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `users/${user.uid}`)
    );

    const unsubMemberships = subscribeUserMemberships(user.uid, (list) => {
      setMemberships(list);
    });

    const unsubInvites = subscribePendingInvites(user.email, (list) => {
      setPendingInvites(list);
    });

    return () => {
      unsubProfile();
      unsubMemberships();
      unsubInvites();
    };
  }, [user?.uid, user?.email]);

  // Resolve activeBusinessId from profile or first available membership
  const resolvedBusinessId = useMemo(() => {
    if (profile?.activeBusinessId && memberships.some((m) => m.businessId === profile.activeBusinessId)) {
      return profile.activeBusinessId;
    }
    return memberships[0]?.businessId || null;
  }, [profile?.activeBusinessId, memberships]);

  // Step 1: Subscribe to authoritative member RBAC doc (must confirm on server first)
  useEffect(() => {
    if (!user?.uid || !resolvedBusinessId) {
      setActiveMember(null);
      setActiveBusiness(null);
      setWorkspaceLoading(false);
      return;
    }

    setWorkspaceLoading(true);
    setActiveMember(null);
    setActiveBusiness(null);

    const unsubMember = onSnapshot(
      doc(db, 'businesses', resolvedBusinessId, 'members', user.uid),
      (snap) => {
        if (snap.metadata.hasPendingWrites) return;
        if (snap.exists()) {
          const memberData = snap.data() as BusinessMember;
          setActiveMember(memberData);
          if (memberData.status !== 'active') {
            setWorkspaceLoading(false);
          }
        } else {
          setActiveMember(null);
          setWorkspaceLoading(false);
        }
      },
      (err) => {
        setActiveMember(null);
        setWorkspaceLoading(false);
        handleFirestoreError(err, OperationType.GET, `businesses/${resolvedBusinessId}/members/${user.uid}`);
      }
    );

    return () => {
      unsubMember();
    };
  }, [user?.uid, resolvedBusinessId]);

  // Step 2: Subscribe to business doc ONLY after server-confirmed active membership exists
  const activeMemberBizId = activeMember?.businessId ?? null;
  const activeMemberStatus = activeMember?.status ?? null;

  useEffect(() => {
    if (!user?.uid || !resolvedBusinessId || activeMemberBizId !== resolvedBusinessId || activeMemberStatus !== 'active') {
      setActiveBusiness(null);
      return;
    }

    const unsubBiz = onSnapshot(
      doc(db, 'businesses', resolvedBusinessId),
      (snap) => {
        if (snap.metadata.hasPendingWrites) return;
        if (snap.exists()) {
          setActiveBusiness({ id: snap.id, ...(snap.data() as Omit<Business, 'id'>) });
        } else {
          setActiveBusiness(null);
        }
        setWorkspaceLoading(false);
      },
      (err) => {
        setActiveBusiness(null);
        setWorkspaceLoading(false);
        handleFirestoreError(err, OperationType.GET, `businesses/${resolvedBusinessId}`);
      }
    );

    return () => {
      unsubBiz();
    };
  }, [user?.uid, resolvedBusinessId, activeMemberBizId, activeMemberStatus]);

  const role =
    activeMember?.status === 'active' &&
    activeMember?.businessId === resolvedBusinessId &&
    activeBusiness?.id === resolvedBusinessId
      ? activeMember.role
      : null;

  const permissions = useMemo(() => {
    const r = role;
    return {
      canViewDashboard: r !== null,
      canManageInventory: r === 'owner' || r === 'manager' || r === 'inventory',
      canAdjustStock: r === 'owner' || r === 'manager' || r === 'inventory',
      canBill: r === 'owner' || r === 'manager' || r === 'cashier',
      canViewCustomers: r === 'owner' || r === 'manager' || r === 'cashier',
      canViewFinance: r === 'owner' || r === 'manager',
      canManageStaff: r === 'owner' || r === 'manager',
      canManageSettings: r === 'owner',
    };
  }, [role]);

  const actor: ActorContext | null = useMemo(() => {
    if (!user || !role) return null;
    return {
      uid: user.uid,
      name: activeMember?.displayName || profile?.displayName || user.displayName || user.email || 'User',
      email: user.email || '',
      role,
    };
  }, [user, role, activeMember?.displayName, profile?.displayName]);

  const signInWithGoogle = async () => {
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Sign-in failed.';
      if (!msg.includes('popup-closed-by-user')) {
        setAuthError(msg);
      }
    }
  };

  const logout = async () => {
    await signOut(auth);
  };

  const switchBusiness = async (businessId: string) => {
    if (!user) return;
    await setActiveBusinessForUser(user.uid, businessId);
  };

  const createBusiness = async (input: CreateBusinessInput) => {
    if (!user || !user.email) throw new Error('You must be signed in.');
    return createBusinessWorkspace(
      {
        uid: user.uid,
        email: user.email,
        displayName: profile?.displayName || user.displayName || user.email.split('@')[0],
      },
      input
    );
  };

  const launchDemoStore = async () => {
    if (!user || !user.email) throw new Error('You must be signed in.');
    return createDemoBusinessWithSeedData({
      uid: user.uid,
      email: user.email,
      displayName: profile?.displayName || user.displayName || user.email.split('@')[0],
    });
  };

  const acceptInvite = async (invite: BusinessInvite) => {
    if (!user || !user.email) throw new Error('You must be signed in.');
    await acceptBusinessInvite(invite, {
      uid: user.uid,
      email: user.email,
      displayName: profile?.displayName || user.displayName || user.email.split('@')[0],
    });
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        memberships,
        pendingInvites,
        activeBusiness,
        activeMember,
        role,
        actor,
        authLoading,
        workspaceLoading,
        authError,
        permissions,
        signInWithGoogle,
        logout,
        switchBusiness,
        createBusiness,
        launchDemoStore,
        acceptInvite,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
